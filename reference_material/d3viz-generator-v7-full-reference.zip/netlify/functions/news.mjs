const BBC_FEED = 'https://feeds.bbci.co.uk/news/technology/rss.xml';
const NRK_TOPIC = 'https://www.nrk.no/emne/teknologi-og-data-1.1849804';
const NRK_LATEST = 'https://www.nrk.no/nyheter/siste.rss';
const UA = 'NewsroomObservatory/0.1 (+visual-news-prototype)';

function decodeEntities(s='') {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1')
    .replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>')
    .replace(/&quot;/g,'"').replace(/&#39;|&apos;/g,"'")
    .replace(/&#(\d+);/g,(_,n)=>String.fromCharCode(Number(n)));
}
function stripHtml(s='') { return decodeEntities(s).replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim(); }
function field(block, tag) {
  const m=block.match(new RegExp(`<${tag}(?:\\s[^>]*)?>([\\s\\S]*?)<\\/${tag}>`,'i'));
  return m ? stripHtml(m[1]) : '';
}
function parseRss(xml, source) {
  const blocks=xml.match(/<item\b[\s\S]*?<\/item>/gi)||[];
  return blocks.map(b=>({
    source, title:field(b,'title'), link:field(b,'link') || field(b,'guid'),
    description:field(b,'description'), published:field(b,'pubDate') || field(b,'dc:date')
  })).filter(x=>x.link).slice(0,12);
}
async function fetchText(url) {
  const r=await fetch(url,{headers:{'user-agent':UA,'accept':'text/html,application/rss+xml,application/xml;q=0.9,*/*;q=0.8'},redirect:'follow'});
  if(!r.ok) throw new Error(`${url} -> ${r.status}`); return r.text();
}
function meta(html, property) {
  const safe=property.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const a=html.match(new RegExp(`<meta[^>]+(?:property|name)=["']${safe}["'][^>]+content=["']([^"']+)["'][^>]*>`,'i'));
  const b=html.match(new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["']${safe}["'][^>]*>`,'i'));
  return decodeEntities((a||b||[])[1]||'').trim();
}
async function hydrateBBC(items) {
  const out=[];
  for (const item of items.slice(0,8)) {
    if(item.title && item.title.length>5) { out.push(item); continue; }
    try {
      const html=await fetchText(item.link); out.push({...item,title:meta(html,'og:title')||meta(html,'twitter:title')||'BBC Technology story',description:item.description||meta(html,'og:description')});
    } catch { out.push({...item,title:item.title||'BBC Technology story'}); }
  }
  return out;
}
function scrapeNrkTopic(html) {
  const items=[]; const seen=new Set();
  const anchor=/<a\b[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi; let m;
  while((m=anchor.exec(html)) && items.length<14) {
    let href=decodeEntities(m[1]); const title=stripHtml(m[2]);
    if(title.length<18 || /logg inn|meny|forside|nyheter|sport|radio|tv/i.test(title)) continue;
    if(href.startsWith('/')) href=`https://www.nrk.no${href}`;
    if(!/^https:\/\/www\.nrk\.no\/.+-1\.\d+/.test(href) || seen.has(href)) continue;
    seen.add(href); items.push({source:'NRK',title,link:href,description:'',published:''});
  }
  return items;
}
function looksTech(item) {
  return /\b(ai|ki|kunstig intelligens|teknologi|data|digital|cyber|internett?|app|robot|chip|programvare|mobil|google|apple|microsoft|meta|openai|tiktok|datasenter)\b/i.test(`${item.title} ${item.description}`);
}

export default async () => {
  let bbc=[],nrk=[],nrkStrategy='topic page';
  const errors=[];
  try { bbc=await hydrateBBC(parseRss(await fetchText(BBC_FEED),'BBC')); } catch(e){errors.push(`BBC: ${e.message}`);}
  try { nrk=scrapeNrkTopic(await fetchText(NRK_TOPIC)); } catch(e){errors.push(`NRK topic: ${e.message}`);}
  if(nrk.length<3) {
    nrkStrategy='latest RSS filtered for technology';
    try { const all=parseRss(await fetchText(NRK_LATEST),'NRK'); nrk=all.filter(looksTech).slice(0,8); if(nrk.length<3){nrkStrategy='latest RSS fallback';nrk=all.slice(0,8);} } catch(e){errors.push(`NRK RSS: ${e.message}`);}
  }
  return new Response(JSON.stringify({updatedAt:new Date().toISOString(),bbc:bbc.slice(0,8),nrk:nrk.slice(0,8),nrkStrategy,errors}),{
    status:200,headers:{'content-type':'application/json; charset=utf-8','cache-control':'public, max-age=300, s-maxage=300','access-control-allow-origin':'*'}
  });
};
