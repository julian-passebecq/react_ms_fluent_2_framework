/* global d3, topojson */

const TOPICS = [
  'All', 'AI', 'Politics', 'Economy', 'Markets', 'Trade', 'Technology',
  'Climate', 'Conflict', 'Health', 'Society', 'Science', 'Culture'
];
const GEOS = ['World', 'North America', 'United States', 'China', 'Europe', 'United Kingdom', 'Middle East', 'Asia', 'Africa'];
const GEO_COUNTRIES = {
  'North America': ['United States', 'Canada', 'Mexico'],
  'Europe': ['United Kingdom', 'France', 'Germany', 'Sweden', 'Ukraine', 'Russia'],
  'Middle East': ['Iran', 'Israel'],
  'Asia': ['China', 'India', 'Japan', 'South Korea'],
  'Africa': ['Sudan', 'Nigeria', 'South Africa']
};
const TOPIC_COLORS = {
  AI: '#e3120b', Politics: '#252525', Economy: '#6d6d68', Markets: '#965c40',
  Trade: '#967534', Technology: '#b3342b', Climate: '#4d7c62', Conflict: '#6f3742',
  Health: '#9c5574', Society: '#5e6486', Science: '#376e89', Culture: '#8a6548'
};
const COUNTRY_ALIASES = {
  'United States of America': 'United States', 'United States': 'United States',
  'United Kingdom': 'United Kingdom', 'South Korea': 'South Korea',
  'Republic of Korea': 'South Korea', 'Russian Federation': 'Russia'
};

const state = {
  mode: 'trends', source: 'Economist', topic: 'All', geo: 'World', issue: null,
  query: '', catalog: null, stats: null, liveNews: [], liveMeta: null,
  selectedNews: null, world: null
};

const VALID_MODES = new Set(['trends','covers','news']);
const VALID_SOURCES = new Set(['Economist','BBC','NRK']);

function restoreUrlState() {
  const params = new URLSearchParams(location.search);
  const mode = params.get('mode');
  const source = params.get('source');
  const topic = params.get('topic');
  const geo = params.get('geo');
  const issue = params.get('issue');
  const q = params.get('q');
  if (VALID_MODES.has(mode)) state.mode = mode;
  if (VALID_SOURCES.has(source)) state.source = source;
  if (TOPICS.includes(topic)) state.topic = topic;
  if (GEOS.includes(geo)) state.geo = geo;
  if (issue && state.catalog?.issues.some(i => i.date === issue)) state.issue = issue;
  if (q) state.query = q.slice(0, 160);
  if (state.mode !== 'news') state.source = 'Economist';
  if (state.mode === 'news' && state.source === 'Economist') state.source = 'BBC';
}

function syncUrlState() {
  const params = new URLSearchParams();
  if (state.mode !== 'trends') params.set('mode', state.mode);
  if (state.source !== 'Economist') params.set('source', state.source);
  if (state.topic !== 'All') params.set('topic', state.topic);
  if (state.geo !== 'World') params.set('geo', state.geo);
  if (state.issue) params.set('issue', state.issue);
  if (state.query) params.set('q', state.query);
  const qs = params.toString();
  const next = `${location.pathname}${qs ? `?${qs}` : ''}${location.hash || ''}`;
  history.replaceState(null, '', next);
}

function syncModeTabs() {
  document.querySelectorAll('.mode-tab[data-mode]').forEach(x => x.classList.toggle('active', x.dataset.mode === state.mode));
}

function a11ySvg(svg, label) {
  return svg.attr('role','img').attr('aria-label', label).attr('focusable','false');
}

const els = {
  root: document.querySelector('#view-root'),
  topics: document.querySelector('#topic-filters'),
  geos: document.querySelector('#geo-filters'),
  issueRail: document.querySelector('#issue-rail'),
  search: document.querySelector('#global-search'),
  searchResults: document.querySelector('#search-results'),
  searchSummary: document.querySelector('#search-summary'),
  status: document.querySelector('#dataset-status'),
  filterSummary: document.querySelector('#filter-summary'),
  resetFilters: document.querySelector('#reset-filters')
};

const icon = (name) => {
  const common = 'viewBox="0 0 24 24" aria-hidden="true"';
  const icons = {
    All: '<rect x="4" y="4" width="6" height="6"/><rect x="14" y="4" width="6" height="6"/><rect x="4" y="14" width="6" height="6"/><rect x="14" y="14" width="6" height="6"/>',
    AI: '<circle cx="12" cy="12" r="3"/><circle cx="5" cy="7" r="2"/><circle cx="19" cy="7" r="2"/><circle cx="5" cy="17" r="2"/><circle cx="19" cy="17" r="2"/><path d="M7 8.5 10 11M17 8.5 14 11M7 15.5 10 13M17 15.5 14 13"/>',
    Politics: '<path d="M3 9h18M5 9V20M10 9V20M14 9V20M19 9V20M3 20h18M12 3 3 8h18z"/>',
    Economy: '<path d="M5 19V11M10 19V7M15 19V13M20 19V4"/>',
    Markets: '<path d="m4 17 5-5 4 3 7-9"/><path d="M16 6h4v4"/>',
    Trade: '<path d="M4 8h14l-3-3M20 16H6l3 3"/>',
    Technology: '<rect x="7" y="7" width="10" height="10" rx="2"/><path d="M9 2v5M15 2v5M9 17v5M15 17v5M2 9h5M2 15h5M17 9h5M17 15h5"/>',
    Climate: '<path d="M19 4C10 4 5 8 5 14c0 4 3 6 6 6 6 0 9-7 8-16Z"/><path d="M7 17c3-4 6-6 10-9"/>',
    Conflict: '<path d="M12 3 4 7v5c0 5 3.5 8 8 9 4.5-1 8-4 8-9V7Z"/><path d="m9 9 6 6M15 9l-6 6"/>',
    Health: '<path d="M12 20S4 15 4 9a4 4 0 0 1 7-2.6A4 4 0 0 1 18 9c0 6-6 11-6 11Z"/>',
    Society: '<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2"/><path d="M3 20c0-4 2-7 6-7s6 3 6 7M15 14c4 0 6 2 6 6"/>',
    Science: '<path d="M9 3h6M10 3v6l-5 9c-.6 1.1.1 3 1.6 3h10.8c1.5 0 2.2-1.9 1.6-3l-5-9V3"/><path d="M8 15h8"/>',
    Culture: '<path d="M4 5h7a3 3 0 0 1 3 3v11H7a3 3 0 0 0-3 2Z"/><path d="M20 5h-3a3 3 0 0 0-3 3v11h3a3 3 0 0 1 3 2Z"/>',
    World: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 4 6 4 9s-1 6-4 9c-3-3-4-6-4-9s1-6 4-9Z"/>',
    'North America': '<path d="m5 5 6-2 7 3 2 5-5 2-2 6-4-2-2-5-3-3Z"/>',
    'United States': '<path d="M3 7h15l3 4-4 6H7l-4-5Z"/>',
    China: '<circle cx="12" cy="12" r="8"/><path d="m12 7 1 3h3l-2.5 1.8 1 3-2.5-1.8-2.5 1.8 1-3L8 10h3Z"/>',
    Europe: '<path d="M5 7 9 3l4 2 4-1 3 5-3 3 1 5-5 4-3-4-5-1-1-5Z"/>',
    'United Kingdom': '<path d="m11 3 4 3-2 3 3 3-2 8-5-2-2-5 2-3-1-4Z"/>',
    'Middle East': '<path d="M5 6h7l3 3 4 1-2 4-5 1-2 4-5-2-1-6Z"/>',
    Asia: '<path d="M3 7 8 3l6 2 6 5-3 5-4 1-2 5-5-3-1-5Z"/>',
    Africa: '<path d="M7 4h8l5 5-3 7-4 5-4-3-2-5-3-4Z"/>'
  };
  return `<svg ${common}>${icons[name] || icons.All}</svg>`;
};

function fmtDate(s) {
  const d = new Date(`${s}T12:00:00Z`);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}
function fmtLongDate(s) {
  const d = new Date(`${s}T12:00:00Z`);
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}
function escapeHtml(v='') {
  return String(v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function niceNum(v) { return new Intl.NumberFormat('en', { maximumFractionDigits: 1 }).format(v); }
function normalizePer10k(count, words) { return count / Math.max(words, 1) * 10000; }
function flattenArticles() {
  return state.catalog.issues.flatMap(issue => issue.articles.map(a => ({...a, issueDate: issue.date, displayDate: issue.displayDate, source:'Economist'})));
}
function matchGeo(regions=[]) {
  if (state.geo === 'World') return true;
  if (regions.includes(state.geo)) return true;
  const members = GEO_COUNTRIES[state.geo];
  return members ? regions.some(r => members.includes(r)) : false;
}
function filteredArticles() {
  return flattenArticles().filter(a => (state.topic === 'All' || a.topics.includes(state.topic)) && matchGeo(a.regions) && (!state.issue || a.issueDate === state.issue));
}
function tooltip() {
  let t = document.querySelector('.tooltip');
  if (!t) { t = document.createElement('div'); t.className='tooltip'; document.body.appendChild(t); }
  return d3.select(t);
}
function showTip(event, html) {
  tooltip().html(html).style('left', `${event.clientX + 12}px`).style('top', `${event.clientY + 12}px`).style('opacity', 1);
}
function hideTip() { tooltip().style('opacity', 0); }


function geoForCountry(name) {
  if (GEOS.includes(name)) return name;
  const entry = Object.entries(GEO_COUNTRIES).find(([, members]) => members.includes(name));
  return entry ? entry[0] : 'World';
}
function applyTopicFilter(topic) {
  state.topic = TOPICS.includes(topic) ? topic : 'All';
  renderFilters(); render();
}
function applyGeoFilter(geo) {
  state.geo = GEOS.includes(geo) ? geo : 'World';
  renderFilters(); render();
}
function updateFilterSummary() {
  if (!els.filterSummary || !els.resetFilters) return;
  const issue = state.issue ? ` · ${fmtDate(state.issue)}` : '';
  els.filterSummary.textContent = `${state.topic === 'All' ? 'All topics' : state.topic} · ${state.geo}${issue}`;
  const isDefault = state.topic === 'All' && state.geo === 'World' && !state.issue;
  els.resetFilters.disabled = isDefault;
}

function renderFilters() {
  els.topics.innerHTML = TOPICS.map(t => `<button class="chip ${state.topic===t?'active':''}" data-topic="${t}" aria-pressed="${state.topic===t}">${icon(t)}<span>${t}</span></button>`).join('');
  els.geos.innerHTML = GEOS.map(g => `<button class="chip ${state.geo===g?'active':''}" data-geo="${g}" aria-pressed="${state.geo===g}">${icon(g)}<span>${g}</span></button>`).join('');
  els.topics.querySelectorAll('[data-topic]').forEach(b => b.addEventListener('click', () => applyTopicFilter(b.dataset.topic)));
  els.geos.querySelectorAll('[data-geo]').forEach(b => b.addEventListener('click', () => applyGeoFilter(b.dataset.geo)));
  updateFilterSummary();
}

function renderIssueRail() {
  els.issueRail.innerHTML = `<button class="issue-link ${!state.issue?'active':''}" data-issue=""><strong>All issues</strong><span>trend view</span></button>` +
    state.catalog.issues.slice().reverse().map(i => `<button class="issue-link ${state.issue===i.date?'active':''}" data-issue="${i.date}"><strong>${fmtDate(i.date)}</strong><span>${escapeHtml(i.cover).slice(0,24)}${i.cover.length>24?'…':''}</span></button>`).join('');
  els.issueRail.querySelectorAll('[data-issue]').forEach(b => b.addEventListener('click', () => {
    state.issue = b.dataset.issue || null;
    renderIssueRail(); updateFilterSummary(); render();
  }));
}

function bindNav() {
  document.querySelectorAll('.mode-tab[data-mode]').forEach(btn => btn.addEventListener('click', () => {
    state.mode = btn.dataset.mode;
    if (state.mode !== 'news') state.source = 'Economist';
    else if (state.source === 'Economist') state.source = 'BBC';
    syncModeTabs();
    syncSourceButtons(); render();
  }));
  document.querySelectorAll('.source-btn').forEach(btn => btn.addEventListener('click', () => {
    state.source = btn.dataset.source;
    if (state.source === 'Economist') {
      if (state.mode === 'news') state.mode = 'trends';
    } else state.mode = 'news';
    syncModeTabs();
    syncSourceButtons(); render();
  }));
  els.search.addEventListener('input', (e) => { state.query = e.target.value.trim(); renderSearch(); syncUrlState(); });
  if (els.resetFilters) els.resetFilters.addEventListener('click', () => {
    state.topic='All'; state.geo='World'; state.issue=null;
    renderFilters(); renderIssueRail(); render();
  });
  const copyView = document.querySelector('#copy-view');
  if (copyView) copyView.addEventListener('click', async () => {
    syncUrlState();
    try {
      await navigator.clipboard.writeText(location.href);
      copyView.textContent='Copied'; copyView.classList.add('copied');
      setTimeout(()=>{copyView.textContent='Copy view';copyView.classList.remove('copied')},1100);
    } catch (_) {
      copyView.textContent='Copy URL'; setTimeout(()=>copyView.textContent='Copy view',1200);
    }
  });
  document.addEventListener('keydown', e => {
    if (e.key === '/' && document.activeElement !== els.search) { e.preventDefault(); els.search.focus(); }
    if (e.key === 'Escape') { state.query=''; els.search.value=''; renderSearch(); syncUrlState(); els.search.blur(); }
  });
}
function syncSourceButtons() {
  document.querySelectorAll('.source-btn').forEach(b => b.classList.toggle('active', b.dataset.source === state.source));
  document.body.classList.toggle('external-mode', state.source !== 'Economist');
}

function renderSearch() {
  const q = state.query.toLowerCase();
  if (!q) { els.searchResults.classList.add('hidden'); els.searchResults.innerHTML=''; els.searchSummary.textContent='Search across the article catalogue and live headlines.'; return; }
  const local = flattenArticles().filter(a => [a.title,a.section,...a.topics,...a.regions,a.displayDate].join(' ').toLowerCase().includes(q));
  const live = state.liveNews.filter(a => [a.title,a.description,a.source].join(' ').toLowerCase().includes(q));
  const hits = [...local.slice(0,12), ...live.slice(0,8)];
  els.searchSummary.textContent = `${local.length + live.length} matches`;
  els.searchResults.classList.remove('hidden');
  els.searchResults.innerHTML = `<div class="search-results-head"><strong>${local.length+live.length} search matches</strong><span>titles · themes · countries · sections</span></div>` + (hits.length ? hits.map(h => `
    <div class="search-hit">
      <div class="source-tag">${escapeHtml(h.source || 'Economist')}</div>
      <div><h4>${escapeHtml(h.title)}</h4><p>${escapeHtml(h.source==='Economist' ? `${h.section} · ${(h.topics||[]).join(', ')} · ${(h.regions||[]).join(', ')}` : (h.description || 'Live headline'))}</p></div>
      <div class="page">${h.page ? `p.${h.page}` : (h.published ? new Date(h.published).toLocaleDateString('en-GB',{day:'numeric',month:'short'}) : '')}</div>
    </div>`).join('') : `<div class="empty-state">No match. Try a broader topic or country.</div>`);
}

function issueSubset() {
  const s = state.stats.issues;
  return state.issue ? s.filter(i => i.date === state.issue) : s;
}
function aggregateCounts(kind) {
  const rows = issueSubset();
  const out = new Map();
  rows.forEach(r => Object.entries(r[kind] || {}).forEach(([k,v]) => out.set(k, (out.get(k)||0)+v)));
  return [...out].map(([name,value]) => ({name,value})).sort((a,b)=>b.value-a.value);
}
function activeCountryNames() {
  if (state.geo === 'World') return null;
  if (GEO_COUNTRIES[state.geo]) return GEO_COUNTRIES[state.geo];
  return [state.geo];
}

function renderTrends() {
  const rows = issueSubset();
  const topicAgg = aggregateCounts('topics');
  const countryAgg = aggregateCounts('countries');
  const topTopic = topicAgg[0] || {name:'-',value:0};
  const topCountry = countryAgg[0] || {name:'-',value:0};
  const filtered = filteredArticles();
  const words = d3.sum(rows, d => d.wordCountApprox);
  els.root.innerHTML = `
  <div class="view">
    <div class="hero-grid">
      <div>
        <div class="eyebrow">The Economist · corpus observatory</div>
        <h1 class="view-title">What keeps returning in the news?</h1>
        <p class="view-deck">A weekly D3 corpus view of themes and countries across your Economist PDFs. Counts are derived from the private issues; publish the analysis, not the source PDFs.</p>
        <p class="view-note">Prototype coverage: ${state.stats.issues.length} issues · ${fmtLongDate(state.stats.issues[0].date)} to ${fmtLongDate(state.stats.issues.at(-1).date)}. Add weekly PDFs and this becomes the year view automatically.</p>
      </div>
      <div class="hero-kpis">
        <div class="kpi"><strong>${rows.length}</strong><span>${state.issue?'selected issue':'issues analysed'}</span></div>
        <div class="kpi"><strong>${niceNum(words/1000)}k</strong><span>approx. corpus words</span></div>
        <div class="kpi"><strong>${escapeHtml(topTopic.name)}</strong><span>most-mentioned tracked theme</span></div>
        <div class="kpi"><strong>${escapeHtml(topCountry.name)}</strong><span>most-mentioned tracked country</span></div>
      </div>
    </div>
    <div class="dashboard-grid">
      <section class="card span-7"><div class="card-head"><div><h3>Theme momentum</h3><p>Mentions per ~10,000 words, issue by issue · click a point or legend item to filter</p></div><span class="micro">${state.topic==='All'?'top themes':state.topic}</span></div><div id="trend-chart" class="chart"></div><div id="trend-legend" class="legend"></div></section>
      <section class="card span-5"><div class="card-head"><div><h3>Country attention</h3><p>Aggregate mentions in selected corpus · click a bar to filter geography</p></div><span class="micro">${state.geo}</span></div><div id="country-bars" class="chart"></div></section>
      <section class="card span-7"><div class="card-head"><div><h3>Geographic footprint</h3><p>Tracked country mentions across the selected issues · click a country to filter</p></div><span class="micro">hover + click</span></div><div id="world-map" class="chart"></div></section>
      <section class="card span-5"><div class="card-head"><div><h3>Topic × geography</h3><p>Catalogue article intersections · click a bubble to apply both filters</p></div><span class="micro">${filtered.length} matching articles</span></div><div id="matrix" class="chart"></div></section>
      <section class="card span-12"><div class="card-head"><div><h3>Article catalogue</h3><p>Use the two filter rows to narrow the issue catalogue</p></div><span class="micro">${filtered.length} shown</span></div><div id="article-table" class="article-table"></div></section>
    </div>
  </div>`;
  drawTrend(); drawCountryBars(); drawWorldMap(); drawMatrix(); drawArticleTable(filtered);
}

function drawTrend() {
  const stats = state.stats.issues;
  const allTotals = aggregateAcrossAll('topics');
  let topics = state.topic === 'All' ? allTotals.slice(0,5).map(d=>d.name) : [state.topic];
  topics = topics.filter(t => stats.some(s => s.topics[t] != null));
  const data = topics.flatMap(topic => stats.map(s => ({date:new Date(`${s.date}T12:00:00Z`), topic, value:normalizePer10k(s.topics[topic]||0,s.wordCountApprox)})));
  const host = document.querySelector('#trend-chart'); if (!host) return;
  const W = 760, H = 300, m={t:12,r:22,b:38,l:45};
  const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Theme momentum line chart. Points can filter the topic.');
  const x=d3.scaleTime().domain(d3.extent(stats,d=>new Date(`${d.date}T12:00:00Z`))).range([m.l,W-m.r]);
  const y=d3.scaleLinear().domain([0,d3.max(data,d=>d.value)*1.14||1]).nice().range([H-m.b,m.t]);
  svg.append('g').attr('class','grid').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5).tickSize(-(W-m.l-m.r)).tickFormat('')).call(g=>g.select('.domain').remove());
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${H-m.b})`).call(d3.axisBottom(x).ticks(stats.length).tickFormat(d3.timeFormat('%d %b')));
  svg.append('g').attr('class','axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(5));
  const line=d3.line().x(d=>x(d.date)).y(d=>y(d.value)).curve(d3.curveMonotoneX);
  topics.forEach(topic=>{
    const pts=data.filter(d=>d.topic===topic); const c=TOPIC_COLORS[topic]||'#333';
    svg.append('path').datum(pts).attr('fill','none').attr('stroke',c).attr('stroke-width',2.2).attr('d',line);
    svg.selectAll(`.pt-${topic.replace(/\W/g,'')}`).data(pts).join('circle').attr('cx',d=>x(d.date)).attr('cy',d=>y(d.value)).attr('r',4).attr('fill','#fff').attr('stroke',c).attr('stroke-width',2).attr('tabindex',0).attr('role','button').attr('aria-label',d=>`${d.topic}, ${d3.timeFormat('%d %b %Y')(d.date)}, ${niceNum(d.value)} mentions per 10k words. Activate to filter topic.`).style('cursor','pointer')
      .on('mousemove',(e,d)=>showTip(e,`<b>${d.topic}</b><br>${d3.timeFormat('%d %b %Y')(d.date)}<br>${niceNum(d.value)} mentions / 10k words<br><small>Click to filter topic</small>`)).on('mouseleave',hideTip)
      .on('click',(e,d)=>applyTopicFilter(d.topic)).on('keydown',(e,d)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();applyTopicFilter(d.topic);}});
  });
  const legend=document.querySelector('#trend-legend');
  legend.innerHTML=topics.map(t=>`<button class="legend-item legend-button" data-trend-topic="${escapeHtml(t)}"><i class="legend-swatch" style="background:${TOPIC_COLORS[t]||'#333'}"></i>${escapeHtml(t)}</button>`).join('');
  legend.querySelectorAll('[data-trend-topic]').forEach(b=>b.addEventListener('click',()=>applyTopicFilter(b.dataset.trendTopic)));
}
function aggregateAcrossAll(kind) {
  const out = new Map(); state.stats.issues.forEach(r=>Object.entries(r[kind]||{}).forEach(([k,v])=>out.set(k,(out.get(k)||0)+v)));
  return [...out].map(([name,value])=>({name,value})).sort((a,b)=>b.value-a.value);
}

function drawCountryBars() {
  const allowed=activeCountryNames();
  let data=aggregateCounts('countries').filter(d=>!allowed || allowed.includes(d.name));
  if (!allowed) data=data.slice(0,10);
  const host=document.querySelector('#country-bars'); if(!host) return;
  if(!data.length){host.innerHTML='<div class="empty-state">No tracked country in this filter.</div>';return;}
  const W=520,H=Math.max(270,data.length*28+48),m={t:12,r:42,b:25,l:105};
  const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Country attention bar chart. Bars can filter geography.');
  const x=d3.scaleLinear().domain([0,d3.max(data,d=>d.value)]).nice().range([m.l,W-m.r]);
  const y=d3.scaleBand().domain(data.map(d=>d.name)).range([m.t,H-m.b]).padding(.32);
  svg.append('g').attr('class','grid').attr('transform',`translate(0,${H-m.b})`).call(d3.axisBottom(x).ticks(4).tickSize(-(H-m.t-m.b)).tickFormat('')).call(g=>g.select('.domain').remove());
  svg.append('g').attr('class','axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).tickSize(0)).call(g=>g.select('.domain').remove());
  svg.selectAll('rect.bar').data(data).join('rect').attr('class','bar interactive-mark').attr('x',m.l).attr('y',d=>y(d.name)).attr('height',y.bandwidth()).attr('width',d=>x(d.value)-m.l).attr('rx',3).attr('fill','#272727').attr('tabindex',0).attr('role','button').attr('aria-label',d=>`${d.name}, ${d.value} tracked mentions. Activate to filter ${geoForCountry(d.name)}.`)
    .on('mousemove',(e,d)=>{const target=geoForCountry(d.name);showTip(e,`<b>${d.name}</b><br>${d.value} tracked mentions<br><small>Click → ${target}</small>`)}).on('mouseleave',hideTip)
    .on('click',(e,d)=>applyGeoFilter(geoForCountry(d.name))).on('keydown',(e,d)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();applyGeoFilter(geoForCountry(d.name));}});
  svg.selectAll('text.val').data(data).join('text').attr('class','val').attr('x',d=>x(d.value)+5).attr('y',d=>y(d.name)+y.bandwidth()/2+3).attr('font-size',9).attr('fill','#777').text(d=>d.value);
}

async function drawWorldMap() {
  const host=document.querySelector('#world-map'); if(!host) return;
  const counts=new Map(aggregateCounts('countries').map(d=>[d.name,d.value]));
  const W=760,H=350;
  try {
    if(!state.world) {
      const r=await fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json');
      if(!r.ok) throw new Error('map data unavailable');
      const topo=await r.json(); state.world=topojson.feature(topo,topo.objects.countries).features;
    }
    const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Geographic footprint world map. Mentioned countries can filter geography.');
    const proj=d3.geoNaturalEarth1().fitExtent([[8,8],[W-8,H-8]],{type:'FeatureCollection',features:state.world});
    const path=d3.geoPath(proj); const max=d3.max([...counts.values()])||1; const color=d3.scaleSequential([0,max],d3.interpolateReds);
    svg.selectAll('path').data(state.world).join('path').attr('d',path).attr('fill',d=>{
      const raw=d.properties?.name || ''; const name=COUNTRY_ALIASES[raw]||raw; const v=counts.get(name)||0; return v?color(v):'#f0efeb';
    }).attr('stroke','#fff').attr('stroke-width',.5).attr('class','interactive-country').attr('tabindex',d=>counts.get(COUNTRY_ALIASES[d.properties?.name||'']||d.properties?.name||'')?0:null).attr('role',d=>counts.get(COUNTRY_ALIASES[d.properties?.name||'']||d.properties?.name||'')?'button':null).attr('aria-label',d=>{const raw=d.properties?.name||'';const name=COUNTRY_ALIASES[raw]||raw;const v=counts.get(name)||0;return v?`${name}, ${v} tracked mentions. Activate to filter ${geoForCountry(name)}.`:null;})
      .on('mousemove',(e,d)=>{const raw=d.properties?.name||'Unknown';const name=COUNTRY_ALIASES[raw]||raw;const v=counts.get(name)||0;showTip(e,`<b>${name}</b><br>${v} tracked mentions${v?`<br><small>Click → ${geoForCountry(name)}</small>`:''}`);}).on('mouseleave',hideTip)
      .on('click',(e,d)=>{const raw=d.properties?.name||'';const name=COUNTRY_ALIASES[raw]||raw;if(counts.get(name))applyGeoFilter(geoForCountry(name));})
      .on('keydown',(e,d)=>{if(e.key!=='Enter'&&e.key!==' ')return;const raw=d.properties?.name||'';const name=COUNTRY_ALIASES[raw]||raw;if(counts.get(name)){e.preventDefault();applyGeoFilter(geoForCountry(name));}});
  } catch(err) {
    const data=aggregateCounts('countries').slice(0,15);
    host.innerHTML=`<div class="empty-state">World-map geometry could not load. Country counts remain available below.</div><div class="country-tiles">${data.map(d=>`<span><b>${escapeHtml(d.name)}</b>${d.value}</span>`).join('')}</div>`;
  }
}

function drawMatrix() {
  const arts=filteredArticles();
  const topics=TOPICS.filter(t=>t!=='All').filter(t=>arts.some(a=>a.topics.includes(t))).slice(0,8);
  const geos=['North America','Europe','Asia','Middle East','Africa','Global'].filter(g=>arts.some(a=>a.regions.includes(g) || (GEO_COUNTRIES[g]||[]).some(x=>a.regions.includes(x))));
  const host=document.querySelector('#matrix'); if(!host) return;
  if(!topics.length||!geos.length){host.innerHTML='<div class="empty-state">No topic × geography intersections for this filter.</div>';return;}
  const cells=[]; topics.forEach(t=>geos.forEach(g=>{const members=GEO_COUNTRIES[g]||[]; const n=arts.filter(a=>a.topics.includes(t) && (a.regions.includes(g)||members.some(x=>a.regions.includes(x)))).length; cells.push({t,g,n});}));
  const W=520,H=300,m={t:18,r:12,b:74,l:86}; const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Topic by geography bubble matrix. Bubbles apply topic and geography filters.');
  const x=d3.scaleBand().domain(geos).range([m.l,W-m.r]).padding(.12), y=d3.scaleBand().domain(topics).range([m.t,H-m.b]).padding(.12); const max=d3.max(cells,d=>d.n)||1; const r=d3.scaleSqrt().domain([0,max]).range([0,Math.min(x.bandwidth(),y.bandwidth())*.38]);
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${H-m.b})`).call(d3.axisBottom(x).tickSize(0)).call(g=>g.select('.domain').remove()).selectAll('text').attr('transform','rotate(-32)').style('text-anchor','end');
  svg.append('g').attr('class','axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).tickSize(0)).call(g=>g.select('.domain').remove());
  svg.selectAll('circle').data(cells.filter(d=>d.n)).join('circle').attr('class','interactive-mark').attr('cx',d=>x(d.g)+x.bandwidth()/2).attr('cy',d=>y(d.t)+y.bandwidth()/2).attr('r',d=>r(d.n)).attr('fill',d=>TOPIC_COLORS[d.t]||'#333').attr('fill-opacity',.76).attr('tabindex',0).attr('role','button').attr('aria-label',d=>`${d.t} by ${d.g}, ${d.n} catalogue article${d.n===1?'':'s'}. Activate to apply both filters.`)
    .on('mousemove',(e,d)=>showTip(e,`<b>${d.t} × ${d.g}</b><br>${d.n} catalogue article${d.n===1?'':'s'}<br><small>Click to apply both filters</small>`)).on('mouseleave',hideTip)
    .on('click',(e,d)=>{state.topic=d.t;state.geo=d.g==='Global'?'World':d.g;renderFilters();render();})
    .on('keydown',(e,d)=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();state.topic=d.t;state.geo=d.g==='Global'?'World':d.g;renderFilters();render();}});
}

function drawArticleTable(arts) {
  const host=document.querySelector('#article-table'); if(!host) return;
  const list=arts.slice().sort((a,b)=>b.issueDate.localeCompare(a.issueDate)||a.page-b.page);
  host.innerHTML=list.length?list.map(a=>`<div class="article-row"><div class="section">${escapeHtml(a.section)}<br><span>${fmtDate(a.issueDate)}</span></div><div class="title">${escapeHtml(a.title)}</div><div class="tagline">${a.topics.slice(0,3).map(t=>`<span class="tiny-tag">${escapeHtml(t)}</span>`).join('')}${a.regions.slice(0,1).map(t=>`<span class="tiny-tag">${escapeHtml(t)}</span>`).join('')}</div><div class="page">p.${a.page}</div></div>`).join(''):'<div class="empty-state">No article matches the current filters.</div>';
}

function renderCovers() {
  let issue=state.catalog.issues.find(i=>i.date===state.issue) || state.catalog.issues.at(-1); state.issue=issue.date; renderIssueRail();
  const stats=state.stats.issues.find(i=>i.date===issue.date);
  els.root.innerHTML=`<div class="view">
    <div class="eyebrow">The Economist · cover story laboratory</div><h1 class="view-title">Turn the cover story into a visual argument.</h1><p class="view-deck">The dashboard does not reproduce the article. It extracts a few stated metrics, the argument structure and the issue’s wider topic fingerprint, then redraws them with D3.</p>
    <div class="issue-selector">${state.catalog.issues.map(i=>`<button class="issue-pill ${i.date===issue.date?'active':''}" data-cover-issue="${i.date}">${i.displayDate}</button>`).join('')}</div>
    <section class="cover-hero"><div class="cover-poster" style="background:${issue.accent}"><div><div class="mast">The Economist</div><div class="date">${escapeHtml(issue.displayDate)}</div></div><div><h2>${escapeHtml(issue.cover)}</h2><p>${escapeHtml(issue.coverDeck)}</p></div></div><div class="cover-analysis"><div class="eyebrow">Derived cover analysis</div><h3>${escapeHtml(issue.cover)}</h3><p>${escapeHtml(issue.coverDeck)}</p><div class="metric-grid">${issue.coverMetrics.map(m=>`<div class="metric"><strong>${escapeHtml(m.display)}</strong><span>${escapeHtml(m.label)} · ${escapeHtml(m.note)}</span></div>`).join('')}</div></div></section>
    <div class="dashboard-grid">
      <section class="card span-6"><div class="card-head"><div><h3>Argument flow</h3><p>Editorial thesis converted into a five-step visual sequence</p></div><span class="micro">D3 flow</span></div><div id="argument-flow" class="chart"></div></section>
      <section class="card span-6"><div class="card-head"><div><h3>Issue fingerprint</h3><p>Tracked full-issue mentions per 10k words</p></div><span class="micro">${fmtLongDate(issue.date)}</span></div><div id="fingerprint" class="chart"></div></section>
      <section class="card span-12"><div class="card-head"><div><h3>Stories around the cover</h3><p>The surrounding issue catalogue is the context layer</p></div><span class="micro">${issue.articles.length} curated entries</span></div><div id="article-table" class="article-table"></div></section>
    </div>
  </div>`;
  document.querySelectorAll('[data-cover-issue]').forEach(b=>b.addEventListener('click',()=>{state.issue=b.dataset.coverIssue;renderIssueRail();renderCovers();}));
  drawArgumentFlow(issue); drawFingerprint(stats); drawArticleTable(issue.articles.map(a=>({...a,issueDate:issue.date,displayDate:issue.displayDate,source:'Economist'})));
}

function drawArgumentFlow(issue) {
  const host=document.querySelector('#argument-flow'); if(!host)return; const W=650,H=300;
  const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Cover story argument flow diagram.'); const steps=issue.argumentFlow.map((label,i)=>({label,i,x:60+i*(530/(issue.argumentFlow.length-1)),y:135+(i%2?25:-25)}));
  svg.selectAll('line').data(d3.pairs(steps)).join('line').attr('x1',d=>d[0].x).attr('y1',d=>d[0].y).attr('x2',d=>d[1].x).attr('y2',d=>d[1].y).attr('stroke','#c9c9c3').attr('stroke-width',2);
  svg.selectAll('circle').data(steps).join('circle').attr('cx',d=>d.x).attr('cy',d=>d.y).attr('r',16).attr('fill',issue.accent).attr('stroke','#fff').attr('stroke-width',3);
  svg.selectAll('text.num').data(steps).join('text').attr('x',d=>d.x).attr('y',d=>d.y+4).attr('text-anchor','middle').attr('fill','#fff').attr('font-weight',800).attr('font-size',10).text(d=>d.i+1);
  steps.forEach(d=>{const fo=svg.append('foreignObject').attr('x',d.x-56).attr('y',d.y+(d.i%2?-78:29)).attr('width',112).attr('height',65);fo.append('xhtml:div').style('font-size','9px').style('line-height','1.25').style('text-align','center').style('color','#555').text(d.label);});
}
function drawFingerprint(stats) {
  const host=document.querySelector('#fingerprint'); if(!host||!stats)return;
  const data=Object.entries(stats.topics).map(([name,count])=>({name,value:normalizePer10k(count,stats.wordCountApprox)})).sort((a,b)=>b.value-a.value);
  const W=650,H=300,m={t:10,r:30,b:75,l:35};const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Issue topic fingerprint bar chart.');const x=d3.scaleBand().domain(data.map(d=>d.name)).range([m.l,W-m.r]).padding(.26), y=d3.scaleLinear().domain([0,d3.max(data,d=>d.value)]).nice().range([H-m.b,m.t]);
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${H-m.b})`).call(d3.axisBottom(x).tickSize(0)).call(g=>g.select('.domain').remove()).selectAll('text').attr('transform','rotate(-35)').style('text-anchor','end');
  svg.append('g').attr('class','axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(4));
  svg.selectAll('rect').data(data).join('rect').attr('x',d=>x(d.name)).attr('y',d=>y(d.value)).attr('height',d=>H-m.b-y(d.value)).attr('width',x.bandwidth()).attr('rx',3).attr('fill',d=>TOPIC_COLORS[d.name]||'#555').on('mousemove',(e,d)=>showTip(e,`<b>${d.name}</b><br>${niceNum(d.value)} mentions / 10k words`)).on('mouseleave',hideTip);
}

function renderNews() {
  const selected = state.source === 'NRK' ? 'NRK' : 'BBC';
  const panel = selected === 'BBC'
    ? `<section class="source-panel"><div class="source-panel-head"><h3>BBC Technology</h3><a href="https://www.bbc.com/technology" target="_blank" rel="noreferrer">open section ↗</a></div><div id="bbc-list"><div class="empty-state">Loading BBC feed…</div></div></section>`
    : `<section class="source-panel"><div class="source-panel-head"><h3>NRK · Teknologi og data</h3><a href="https://www.nrk.no/emne/teknologi-og-data-1.1849804" target="_blank" rel="noreferrer">open topic ↗</a></div><div id="nrk-list"><div class="empty-state">Loading NRK feed…</div></div></section>`;
  els.root.innerHTML=`<div class="view"><div class="eyebrow">${selected} · lightweight visual journalism</div><h1 class="view-title">Headline in. Visual story out.</h1><p class="view-deck">The live layer pulls ${selected === 'BBC' ? 'BBC Technology' : 'NRK technology-oriented'} headlines server-side, then lets you turn one small article into three compact D3 views. Topic and geography chips also filter the feed text. The site links back to the publisher rather than republishing the article.</p>
    <details class="article-studio"><summary>Paste an article or excerpt → build 3 D3 visuals</summary><div class="studio-grid"><label><span>Title</span><input id="paste-title" placeholder="Optional article title"></label><label class="studio-text"><span>Article / excerpt</span><textarea id="paste-text" rows="7" placeholder="Paste the text you are allowed to analyse. It stays in your browser in this prototype."></textarea></label><button id="build-paste" class="primary-btn">Build visual story</button></div></details>
    <div class="news-toolbar"><p id="news-meta">${state.liveMeta ? `Last feed refresh: ${new Date(state.liveMeta.updatedAt).toLocaleString()}` : 'Live feeds load through the Netlify function.'}</p><button id="refresh-news" class="refresh-btn">Refresh live sources</button></div>
    <div class="news-columns single">${panel}</div><div id="visual-story"></div></div>`;
  document.querySelector('#refresh-news').addEventListener('click',()=>loadLiveNews(true));
  document.querySelector('#build-paste').addEventListener('click',()=>{
    const text=document.querySelector('#paste-text').value.trim();
    if(!text){document.querySelector('#paste-text').focus();return;}
    state.selectedNews={source:selected,title:document.querySelector('#paste-title').value.trim()||'Pasted article',description:text,pasted:true};
    drawNewsVisual(state.selectedNews);
    document.querySelector('#visual-story')?.scrollIntoView({behavior:'smooth',block:'start'});
  });
  if(state.liveNews.length) { renderNewsLists(); if(state.selectedNews) drawNewsVisual(state.selectedNews); }
  else loadLiveNews(false);
}

async function loadLiveNews(force=false) {
  const btn=document.querySelector('#refresh-news'); if(btn){btn.disabled=true;btn.textContent='Refreshing…';}
  try {
    const url=`/.netlify/functions/news${force?`?t=${Date.now()}`:''}`; const r=await fetch(url); if(!r.ok)throw new Error(`feed function returned ${r.status}`); const payload=await r.json();
    const rows=[...(payload.bbc||[]),...(payload.nrk||[])]; if(!rows.length)throw new Error('feed returned no articles');
    state.liveNews=rows; state.liveMeta={updatedAt:payload.updatedAt,nrkStrategy:payload.nrkStrategy};
  } catch(err) {
    try { const r=await fetch('./data/news_fallback.json'); const payload=await r.json(); state.liveNews=payload.items||[];state.liveMeta={updatedAt:payload.generatedAt,fallback:true,error:err.message}; } catch(_) { state.liveNews=[];state.liveMeta={fallback:true,error:err.message}; }
  }
  if(document.querySelector('#bbc-list')) { renderNewsLists(); const meta=document.querySelector('#news-meta'); if(meta) meta.textContent=state.liveMeta?.fallback?'Local preview: cached/demo cards. Deploy to Netlify for live feeds.':`Live refresh ${new Date(state.liveMeta.updatedAt).toLocaleString()} · NRK strategy: ${state.liveMeta.nrkStrategy||'topic page / RSS'}`; }
  if(btn){btn.disabled=false;btn.textContent='Refresh live sources';}
  renderSearch();
}
function renderNewsLists() {
  ['BBC','NRK'].forEach(src=>{
    const host=document.querySelector(`#${src.toLowerCase()}-list`); if(!host)return; const rows=state.liveNews.filter(d=>d.source===src && matchesLiveFilters(d)).slice(0,8);
    host.innerHTML=rows.length?rows.map((d,i)=>`<article class="news-card"><div class="meta"><span class="${d.demo?'':'live-badge'}">${d.demo?'DEMO / CACHED':'LIVE'}</span>${d.published?`<span>${new Date(d.published).toLocaleDateString('en-GB',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'})}</span>`:''}</div><h4>${escapeHtml(d.title)}</h4>${d.description?`<p>${escapeHtml(d.description).slice(0,220)}${d.description.length>220?'…':''}</p>`:''}<div class="news-actions"><button class="visualize-btn" data-news="${encodeURIComponent(src+'|'+i)}">Visualize with D3</button>${d.link?`<a href="${escapeHtml(d.link)}" target="_blank" rel="noreferrer">read at ${src} ↗</a>`:''}</div></article>`).join(''):'<div class="empty-state">No ${src} items returned. The source may have changed its feed/page structure.</div>';
  });
  document.querySelectorAll('[data-news]').forEach(b=>b.addEventListener('click',()=>{const [src,idx]=decodeURIComponent(b.dataset.news).split('|');state.selectedNews=state.liveNews.filter(d=>d.source===src)[Number(idx)];drawNewsVisual(state.selectedNews);document.querySelector('#visual-story')?.scrollIntoView({behavior:'smooth',block:'start'});}));
}

const STORY_TOPICS = {
  AI: /\b(ai|artificial intelligence|chatgpt|model|algorithm|kunstig intelligens|ki\b|maskinlæring|robot)/ig,
  Technology: /\b(technology|tech|software|hardware|data|digital|cyber|internet|app|chip|computer|teknologi|digital|programvare|nett)/ig,
  Markets: /\b(market|price|stock|shares|revenue|profit|billion|million|marked|pris|aksj|inntekt|milliard|million)/ig,
  Economy: /\b(economy|economic|growth|gdp|inflation|jobs?|employment|økonomi|vekst|inflasjon|arbeidsledighet)/ig,
  Trade: /\b(trade|tariff|export|import|sanction|handel|toll|eksport|import|sanksjon)/ig,
  Politics: /\b(government|minister|court|law|regulation|policy|state|president|government|regjering|minister|lov|domstol|politikk)/ig,
  Climate: /\b(climate|carbon|energy|warming|emission|weather|klima|energi|utslipp|vær)/ig,
  Conflict: /\b(war|military|attack|weapon|security|krig|militær|angrep|våpen|sikkerhet)/ig,
  Health: /\b(health|medicine|disease|hospital|vaccine|helse|sykdom|sykehus|vaksine)/ig,
  Science: /\b(science|research|scientist|study|space|forskning|forsker|vitenskap|romfart)/ig,
  Culture: /\b(culture|music|film|book|art|gaming|kultur|musikk|film|bok|kunst|spill)/ig,
  Society: /\b(people|children|work|jobs|education|school|social|barn|arbeid|jobb|skole|samfunn)/ig
};
const LIVE_GEO_PATTERNS = {
  'United States': /\b(united states|u\.?s\.?|america|american|usa)\b/i,
  'China': /\b(china|chinese|kina|kinesisk)\b/i,
  'United Kingdom': /\b(united kingdom|britain|british|uk|storbritannia|britisk)\b/i,
  'Canada': /\b(canada|canadian|kanada|kanadisk)\b/i,
  'Mexico': /\b(mexico|mexican|mexico|meksikansk)\b/i,
  'France': /\b(france|french|frankrike|fransk)\b/i,
  'Germany': /\b(germany|german|tyskland|tysk)\b/i,
  'Sweden': /\b(sweden|swedish|sverige|svensk)\b/i,
  'Ukraine': /\b(ukraine|ukrainian|ukraina|ukrainsk)\b/i,
  'Russia': /\b(russia|russian|russland|russisk)\b/i,
  'Iran': /\b(iran|iranian|iransk)\b/i,
  'Israel': /\b(israel|israeli|israelsk)\b/i,
  'India': /\b(india|indian|india|indisk)\b/i,
  'Japan': /\b(japan|japanese|japansk)\b/i,
  'South Korea': /\b(south korea|korean|sør-korea|sørkorea|koreansk)\b/i,
  'Sudan': /\b(sudan|sudanese|sudansk)\b/i,
  'Nigeria': /\b(nigeria|nigerian|nigeriansk)\b/i,
  'South Africa': /\b(south africa|south african|sør-afrika|sørafrikansk)\b/i
};
function matchesLiveFilters(article) {
  const text = `${article.title || ''} ${article.description || ''}`;
  if (state.topic !== 'All') {
    const re = STORY_TOPICS[state.topic];
    if (!re) return false;
    re.lastIndex = 0;
    if (!re.test(text)) return false;
  }
  if (state.geo === 'World') return true;
  const members = GEO_COUNTRIES[state.geo] || [state.geo];
  return members.some(c => LIVE_GEO_PATTERNS[c]?.test(text));
}
function analyseStory(article) {
  const text=`${article.title||''} ${article.description||''}`; const scores=Object.entries(STORY_TOPICS).map(([topic,re])=>({topic,score:(text.match(re)||[]).length})).filter(d=>d.score).sort((a,b)=>b.score-a.score);
  const stop=new Set('the a an and or but of to in for on with from by is are was were be as at it its this that these those into over after about more new has have had will can may their they them you your der det den en et og i på av til for med som er var fra har skal kan om etter over nye new said says say this that'.split(' '));
  const words=(text.toLowerCase().match(/[a-zæøå0-9-]{4,}/gi)||[]).filter(w=>!stop.has(w) && !/^\d+$/.test(w)); const freq=d3.rollups(words,v=>v.length,d=>d).map(([word,count])=>({word,count})).sort((a,b)=>b.count-a.count).slice(0,18);
  const numbers=(text.match(/(?:[$£€]\s?)?\d+(?:[.,]\d+)?(?:\s?(?:%|bn|m|million|billion|mrd|mill\.))?/gi)||[]).slice(0,8);
  const sentences=(text.match(/[^.!?]+[.!?]?/g)||[]).map(x=>x.trim()).filter(x=>x.length>8).slice(0,40).map((sentence,i)=>({i:i+1,words:(sentence.match(/[A-Za-zÆØÅæøå0-9'-]+/g)||[]).length}));
  return {scores:scores.length?scores:[{topic:'General',score:1}],freq,numbers,sentences};
}
function drawNewsVisual(article) {
  const host=document.querySelector('#visual-story'); if(!host||!article)return; const a=analyseStory(article);
  host.innerHTML=`<section class="visual-story"><div class="eyebrow">Article → 3 D3 views · ${escapeHtml(article.source)}</div><h3>${escapeHtml(article.title)}</h3><div class="sub">${article.pasted?'Built locally from your pasted text.':'Built from the headline + feed description.'} These are transparent text signals, not a substitute for reading the source.</div><div class="dashboard-grid"><div class="card span-4"><div class="card-head"><div><h3>1 · Theme signal</h3><p>Controlled keyword intensity</p></div></div><div id="story-topics" class="chart"></div></div><div class="card span-4"><div class="card-head"><div><h3>2 · Term constellation</h3><p>Recurring non-stopword terms</p></div></div><div id="story-terms" class="chart"></div></div><div class="card span-4"><div class="card-head"><div><h3>3 · Text rhythm</h3><p>Sentence length across the excerpt</p></div></div><div id="story-rhythm" class="chart"></div></div></div>${a.numbers.length?`<div class="number-strip"><span>Numbers detected</span>${a.numbers.map(n=>`<b>${escapeHtml(n)}</b>`).join('')}</div>`:''}</section>`;
  drawStoryTopics(a.scores); drawStoryTerms(a.freq); drawStoryRhythm(a.sentences);
}
function drawStoryTopics(data) {
  const host=document.querySelector('#story-topics'); if(!host)return; const W=600,H=280,m={t:15,r:35,b:35,l:95};const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Article theme signal bar chart.');const x=d3.scaleLinear().domain([0,d3.max(data,d=>d.score)]).range([m.l,W-m.r]), y=d3.scaleBand().domain(data.map(d=>d.topic)).range([m.t,H-m.b]).padding(.34);
  svg.append('g').attr('class','axis').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).tickSize(0)).call(g=>g.select('.domain').remove());
  svg.selectAll('rect').data(data).join('rect').attr('x',m.l).attr('y',d=>y(d.topic)).attr('height',y.bandwidth()).attr('width',d=>Math.max(2,x(d.score)-m.l)).attr('rx',4).attr('fill',d=>TOPIC_COLORS[d.topic]||'#444');
  svg.selectAll('text.v').data(data).join('text').attr('x',d=>x(d.score)+7).attr('y',d=>y(d.topic)+y.bandwidth()/2+3).attr('font-size',9).attr('fill','#777').text(d=>d.score);
}
function drawStoryTerms(data) {
  const host=document.querySelector('#story-terms'); if(!host)return; if(!data.length){host.innerHTML='<div class="empty-state">Not enough feed text for a term constellation.</div>';return;}
  const W=600,H=280;const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Article term constellation bubble layout.');const max=d3.max(data,d=>d.count); const r=d3.scaleSqrt().domain([1,max]).range([12,33]); const nodes=data.map((d,i)=>({...d,r:r(d.count),x:W/2+(i%4-1.5)*80,y:H/2+(Math.floor(i/4)-2)*45}));
  const sim=d3.forceSimulation(nodes).force('center',d3.forceCenter(W/2,H/2)).force('charge',d3.forceManyBody().strength(3)).force('collide',d3.forceCollide(d=>d.r+3)).stop();for(let i=0;i<120;i++)sim.tick();
  svg.selectAll('circle').data(nodes).join('circle').attr('cx',d=>d.x).attr('cy',d=>d.y).attr('r',d=>d.r).attr('fill','#f0efeb').attr('stroke','#c9c9c3');
  svg.selectAll('text').data(nodes).join('text').attr('x',d=>d.x).attr('y',d=>d.y+3).attr('text-anchor','middle').attr('font-size',d=>Math.max(7,Math.min(11,d.r/2.4))).attr('fill','#333').text(d=>d.word.length>12?`${d.word.slice(0,11)}…`:d.word);
}

function drawStoryRhythm(data) {
  const host=document.querySelector('#story-rhythm'); if(!host)return;
  if(!data.length){host.innerHTML='<div class="empty-state">Not enough text for sentence rhythm.</div>';return;}
  const W=560,H=280,m={t:18,r:18,b:38,l:34}; const svg=a11ySvg(d3.select(host).append('svg').attr('viewBox',`0 0 ${W} ${H}`),'Article sentence length bar chart.');
  const x=d3.scaleBand().domain(data.map(d=>d.i)).range([m.l,W-m.r]).padding(.22); const y=d3.scaleLinear().domain([0,d3.max(data,d=>d.words)]).nice().range([H-m.b,m.t]);
  svg.append('g').attr('class','grid').attr('transform',`translate(${m.l},0)`).call(d3.axisLeft(y).ticks(4).tickSize(-(W-m.l-m.r)).tickFormat('')).call(g=>g.select('.domain').remove());
  svg.append('g').attr('class','axis').attr('transform',`translate(0,${H-m.b})`).call(d3.axisBottom(x).tickValues(data.filter((_,i)=>i%Math.ceil(data.length/8)===0).map(d=>d.i)).tickSize(0));
  svg.selectAll('rect').data(data).join('rect').attr('x',d=>x(d.i)).attr('y',d=>y(d.words)).attr('width',x.bandwidth()).attr('height',d=>H-m.b-y(d.words)).attr('rx',2).attr('fill','#343434').attr('fill-opacity',.82).on('mousemove',(e,d)=>showTip(e,`Sentence ${d.i}<br><b>${d.words} words</b>`)).on('mouseleave',hideTip);
}

function render() {
  if(!state.catalog||!state.stats)return;
  updateFilterSummary();
  if(state.mode==='trends') renderTrends(); else if(state.mode==='covers') renderCovers(); else renderNews();
  renderSearch(); syncSourceButtons(); syncModeTabs(); syncUrlState();
}

async function init() {
  bindNav();
  if (typeof window.d3 === 'undefined') {
    els.status.textContent='D3 failed to load';
    els.root.innerHTML='<div class="empty-state"><b>D3.js did not load.</b><br>Check the network/CDN connection, then reload. Local datasets are still intact.</div>';
    return;
  }
  try {
    const [catalog,stats]=await Promise.all([fetch('./data/catalog.json').then(r=>r.json()),fetch('./data/economist_stats.json').then(r=>r.json())]);
    state.catalog=catalog;state.stats=stats;restoreUrlState();els.search.value=state.query;els.status.textContent=`${stats.issues.length} Economist issues indexed`;syncModeTabs();syncSourceButtons();renderFilters();renderIssueRail();render();
  } catch(err) {
    els.status.textContent='Dataset failed to load';els.root.innerHTML=`<div class="empty-state">Could not load local JSON. Run the site through a local HTTP server rather than opening index.html directly.<br><br>${escapeHtml(err.message)}</div>`;
  }
}
init();
