#!/usr/bin/env python3
"""Static smoke test for the Newsroom Observatory V4 bundle."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class IdParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids: list[str] = []
        self.refs: list[tuple[str, str]] = []

    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        if "id" in d:
            self.ids.append(d["id"])
        key = "src" if tag == "script" else "href" if tag in {"link", "a"} else None
        if key and d.get(key):
            self.refs.append((tag, d[key]))


def node_check(path: Path) -> None:
    subprocess.run(["node", "--check", str(path)], check=True, stdout=subprocess.DEVNULL)


def check_html(rel: str) -> None:
    p = ROOT / rel
    parser = IdParser()
    parser.feed(p.read_text(encoding="utf-8"))
    dup = {x for x in parser.ids if parser.ids.count(x) > 1}
    assert not dup, f"{rel}: duplicate ids {sorted(dup)}"
    for _, ref in parser.refs:
        if ref.startswith(("http://", "https://", "#", "mailto:")):
            continue
        ref = ref.split("#", 1)[0]
        if not ref:
            continue
        target = p.parent / ref
        if ref.endswith("/"):
            target = target / "index.html"
        assert target.exists(), f"{rel}: missing local reference {ref}"


def check_recovered_archive() -> tuple[int, int]:
    base = ROOT / "sandbox/recovered"
    manifest = json.loads((base / "SOURCE_INDEX.json").read_text(encoding="utf-8"))
    files = manifest["files"]
    assert manifest["file_count"] == len(files) == 80, "unexpected recovered raw-file count"
    for item in files:
        p = base / item["path"]
        assert p.is_file(), f"missing recovered file {item['path']}"
        raw = p.read_bytes()
        assert len(raw) == item["size"], f"size changed: {item['path']}"
        assert hashlib.sha256(raw).hexdigest() == item["sha256"], f"hash changed: {item['path']}"

    mapped = manifest["demo_source_map"]
    assert len(mapped) >= 11, "expected at least 11 source-backed demo mappings"
    checked_js: set[Path] = set()
    for demo, src in mapped.items():
        for key in ("page", "js", "css", "runnable_page"):
            value = src.get(key)
            if value:
                p = base / value
                assert p.is_file(), f"{demo}: missing {key} {value}"
        for value in src.get("data", []) + src.get("helpers", []):
            assert (base / value).is_file(), f"{demo}: missing source asset {value}"
        js = base / src["js"]
        if js not in checked_js:
            node_check(js)
            checked_js.add(js)

    wrappers = manifest.get("generated_runtime_wrappers", [])
    assert len(wrappers) == 11, "unexpected runnable wrapper count"
    for rel in wrappers:
        p = base / rel
        text = p.read_text(encoding="utf-8")
        assert '<base href="../datavis.fr/">' in text, f"wrapper missing local base: {rel}"
        assert not re.search(r'<script[^>]+src=["\']https?://', text, re.I), f"remote script left in wrapper: {rel}"
    return len(files), len(wrappers)


def main() -> None:
    for rel in ["app.js", "sandbox/sandbox.js", "netlify/functions/news.mjs"]:
        node_check(ROOT / rel)

    for rel in [
        "data/catalog.json",
        "data/economist_stats.json",
        "data/news_fallback.json",
        "sandbox/recovery_inventory.json",
        "sandbox/recovered/SOURCE_INDEX.json",
    ]:
        json.loads((ROOT / rel).read_text(encoding="utf-8"))

    check_html("index.html")
    check_html("sandbox/index.html")
    raw_count, wrapper_count = check_recovered_archive()

    print(
        "PASS: JS syntax, JSON parse, duplicate IDs, local HTML references, "
        f"{raw_count} recovered-file hashes, and {wrapper_count} local comparison wrappers"
    )


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        raise
