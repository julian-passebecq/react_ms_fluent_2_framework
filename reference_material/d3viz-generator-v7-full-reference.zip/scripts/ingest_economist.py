#!/usr/bin/env python3
"""Build derived issue-level topic/country statistics from private Economist PDFs.

The PDFs stay outside the website. Only aggregate counts are written to data/economist_stats.json.
Usage:
  python scripts/ingest_economist.py /path/to/issue1.pdf /path/to/issue2.pdf ...
"""
from __future__ import annotations
import json, re, subprocess, sys
from collections import OrderedDict
from datetime import UTC, datetime
from pathlib import Path

TOPICS = OrderedDict({
    "AI": [r"\bartificial intelligence\b", r"\bai\b", r"\bllm(?:s)?\b", r"\bchatbot(?:s)?\b", r"\bagentic\b"],
    "Politics": [r"\belection(?:s)?\b", r"\bgovernment\b", r"\bpresident\b", r"\bparliament\b", r"\bminister\b", r"\bpolitic(?:s|al)?\b"],
    "Economy": [r"\beconom(?:y|ic|ics)\b", r"\bgdp\b", r"\bgrowth\b", r"\binflation\b", r"\blabou?r\b", r"\bemployment\b"],
    "Markets": [r"\bbond(?:s)?\b", r"\byield(?:s)?\b", r"\bstock(?:s)?\b", r"\bmarket(?:s)?\b", r"\bshares?\b", r"\binvestor(?:s)?\b"],
    "Trade": [r"\btrade\b", r"\btariff(?:s)?\b", r"\bexport(?:s|ed|ing)?\b", r"\bimport(?:s|ed|ing)?\b", r"\bsanction(?:s|ed)?\b"],
    "Technology": [r"\btechnology\b", r"\bsoftware\b", r"\bdata[- ]cent(?:re|er)s?\b", r"\brobot(?:s|ic|ics)?\b", r"\bchips?\b", r"\binternet\b"],
    "Climate": [r"\bclimate\b", r"\bwarming\b", r"\bcarbon\b", r"\bemission(?:s)?\b", r"\bsolar\b", r"\bglacier(?:s)?\b"],
    "Conflict": [r"\bwar\b", r"\bmilitary\b", r"\bmissile(?:s)?\b", r"\battack(?:s|ed|ing)?\b", r"\bdefen[cs]e\b", r"\barmy\b"],
    "Health": [r"\bhealth\b", r"\bvaccine(?:s)?\b", r"\bcancer\b", r"\bmedicine(?:s)?\b", r"\bdisease(?:s)?\b"],
    "Society": [r"\bmigration\b", r"\bimmigra(?:nt|nts|tion)\b", r"\beducation\b", r"\bculture\b", r"\breligion\b", r"\bpopulation\b"],
})

COUNTRIES = OrderedDict({
    "United States": [r"\bunited states\b", r"\bamerica(?:n|ns|'s)?\b", r"\bu\.s\.\b"],
    "China": [r"\bchina\b", r"\bchinese\b"],
    "United Kingdom": [r"\bbritain\b", r"\bbritish\b", r"\bunited kingdom\b", r"\buk\b"],
    "Iran": [r"\biran\b", r"\biranian\b"],
    "Ukraine": [r"\bukraine\b", r"\bukrainian\b"],
    "Russia": [r"\brussia\b", r"\brussian\b"],
    "India": [r"\bindia\b", r"\bindian\b"],
    "Israel": [r"\bisrael\b", r"\bisraeli\b"],
    "Canada": [r"\bcanada\b", r"\bcanadian\b"],
    "France": [r"\bfrance\b", r"\bfrench\b"],
    "Germany": [r"\bgermany\b", r"\bgerman\b"],
    "Japan": [r"\bjapan\b", r"\bjapanese\b"],
    "South Korea": [r"\bsouth korea\b", r"\bsouth korean\b"],
    "Brazil": [r"\bbrazil\b", r"\bbrazilian\b"],
    "Australia": [r"\baustralia\b", r"\baustralian\b"],
    "Sweden": [r"\bsweden\b", r"\bswedish\b"],
    "Sudan": [r"\bsudan\b", r"\bsudanese\b"],
    "Nigeria": [r"\bnigeria\b", r"\bnigerian\b"],
    "South Africa": [r"\bsouth africa\b", r"\bsouth african\b"],
    "Mexico": [r"\bmexico\b", r"\bmexican\b"],
})

DATE_PATTERNS = [
    re.compile(r"AUGUST\s+(\d{1,2})(?:TH|ST|ND|RD)[^\n]{0,40}(2026)", re.I),
    re.compile(r"The Economist\s+August\s+(\d{1,2})(?:th|st|nd|rd)\s+(2026)", re.I),
]

def text_from_pdf(path: Path) -> str:
    p = subprocess.run(["pdftotext", "-layout", str(path), "-"], check=True, capture_output=True, text=True, errors="ignore")
    return p.stdout

def editorial_corpus(text: str) -> tuple[str, int, int]:
    """Keep editorial pages and drop covers/ads/TOC/indicator tables.

    pdftotext preserves page breaks as form-feed characters. Economist editorial
    pages normally carry a running "The Economist" header; display ads usually do
    not. This heuristic is deliberately simple and auditable.
    """
    pages = [p.strip() for p in text.split("\f") if p.strip()]
    kept = []
    for page in pages:
        head = page[:700]
        if "The Economist" not in head:
            continue
        if re.search(r"\bContents\b", head, re.I):
            continue
        if re.search(r"Economic\s*&\s*financial indicators", head, re.I):
            continue
        if re.search(r"Subscription service", head, re.I):
            continue
        kept.append(page)
    return "\n\f\n".join(kept), len(kept), len(pages)

def count_patterns(text: str, pats: list[str]) -> int:
    return sum(len(re.findall(p, text, re.I)) for p in pats)

def infer_date(text: str, path: Path) -> str:
    head = text[:12000]
    for pat in DATE_PATTERNS:
        m = pat.search(head)
        if m:
            return datetime(int(m.group(2)), 8, int(m.group(1))).date().isoformat()
    m = re.search(r"(?:_|\s)(\d{1,2})[ _-]?August[ _-]?(2026)", path.name, re.I)
    if m:
        return datetime(int(m.group(2)), 8, int(m.group(1))).date().isoformat()
    raise ValueError(f"Could not infer issue date from {path}")

def normalize(counts: dict[str,int]) -> dict[str,int]:
    return dict(sorted(counts.items(), key=lambda kv: (-kv[1], kv[0])))

def main(paths: list[str]) -> None:
    issues = []
    for raw in paths:
        path = Path(raw)
        text = text_from_pdf(path)
        corpus, used_pages, total_pages = editorial_corpus(text)
        issue = {
            "date": infer_date(text, path),
            "sourceFile": path.name,
            "wordCountApprox": len(re.findall(r"\b[\w’-]+\b", corpus)),
            "editorialPagesUsed": used_pages,
            "pdfPages": total_pages,
            "topics": normalize({k: count_patterns(corpus, v) for k,v in TOPICS.items()}),
            "countries": normalize({k: count_patterns(corpus, v) for k,v in COUNTRIES.items()}),
        }
        issues.append(issue)
        print(f"processed {path.name}: {issue['date']}")
    issues.sort(key=lambda x: x["date"])
    out = Path(__file__).resolve().parents[1] / "data" / "economist_stats.json"
    out.write_text(json.dumps({"generatedAt": datetime.now(UTC).isoformat().replace("+00:00", "Z"), "issues": issues}, indent=2), encoding="utf-8")
    print(f"wrote {out}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        raise SystemExit(2)
    main(sys.argv[1:])
