/* global d3, state, els, render, VALID_MODES, syncModeTabs, syncSourceButtons, syncUrlState */

(() => {
  const CURRENT_SOURCE = 'https://www.skyscrapercenter.com/buildings?status=completed';
  const CLASSIC_SOURCE = 'https://gist.github.com/leathl16/af78c56cce65c1f1d30c';
  const FT_SOURCE = 'https://johnburnmurdoch.github.io/d3-london/';

  const currentBuildings = [
    { rank: 1, name: 'Burj Khalifa', short: 'Burj Khalifa', city: 'Dubai', heightM: 828 },
    { rank: 2, name: 'Merdeka 118', short: 'Merdeka 118', city: 'Kuala Lumpur', heightM: 679 },
    { rank: 3, name: 'Shanghai Tower', short: 'Shanghai Tower', city: 'Shanghai', heightM: 632 },
    { rank: 4, name: 'Makkah Royal Clock Tower', short: 'Makkah Clock', city: 'Mecca', heightM: 601 },
    { rank: 5, name: 'Ping An Finance Center', short: 'Ping An', city: 'Shenzhen', heightM: 599 },
    { rank: 6, name: 'Lotte World Tower', short: 'Lotte World', city: 'Seoul', heightM: 555 },
    { rank: 7, name: 'One World Trade Center', short: 'One WTC', city: 'New York City', heightM: 541 },
    { rank: 8, name: 'Guangzhou CTF Finance Centre', short: 'Guangzhou CTF', city: 'Guangzhou', heightM: 530 },
    { rank: 8, name: 'Tianjin CTF Finance Centre', short: 'Tianjin CTF', city: 'Tianjin', heightM: 530 },
    { rank: 10, name: 'CITIC Tower', short: 'CITIC Tower', city: 'Beijing', heightM: 528 },
    { rank: 11, name: 'TAIPEI 101', short: 'Taipei 101', city: 'Taipei', heightM: 508 },
    { rank: 12, name: 'Shanghai World Financial Center', short: 'Shanghai WFC', city: 'Shanghai', heightM: 492 },
    { rank: 13, name: 'International Commerce Centre', short: 'ICC', city: 'Hong Kong', heightM: 484 },
    { rank: 14, name: 'Wuhan Greenland Center', short: 'Wuhan Greenland', city: 'Wuhan', heightM: 476 },
    { rank: 15, name: 'Central Park Tower', short: 'Central Park', city: 'New York City', heightM: 472 }
  ];

  const classicBuildings = [
    { name: 'Burj Khalifa', short: 'Burj Khalifa', city: 'Dubai', country: 'United Arab Emirates', heightM: 828, floors: 163, completed: 2010 },
    { name: 'Makkah Royal Clock Tower', short: 'Makkah Clock', city: 'Mecca', country: 'Saudi Arabia', heightM: 601, floors: 120, completed: 2012 },
    { name: 'One World Trade Center', short: 'One WTC', city: 'New York City', country: 'United States', heightM: 541, floors: 94, completed: 2014 },
    { name: 'Taipei 101', short: 'Taipei 101', city: 'Taipei', country: 'Taiwan', heightM: 508, floors: 101, completed: 2004 },
    { name: 'Shanghai World Financial Center', short: 'Shanghai WFC', city: 'Shanghai', country: 'China', heightM: 492, floors: 101, completed: 2008 },
    { name: 'International Commerce Centre', short: 'ICC', city: 'Hong Kong', country: 'China', heightM: 484, floors: 108, completed: 2010 },
    { name: 'Petronas Twin Towers', short: 'Petronas', city: 'Kuala Lumpur', country: 'Malaysia', heightM: 452, floors: 88, completed: 1998 },
    { name: 'Zifeng Tower', short: 'Zifeng Tower', city: 'Nanjing', country: 'China', heightM: 450, floors: 66, completed: 2010 },
    { name: 'Willis Tower', short: 'Willis Tower', city: 'Chicago', country: 'United States', heightM: 442, floors: 108, completed: 1974 },
    { name: 'KK100', short: 'KK100', city: 'Shenzhen', country: 'China', heightM: 442, floors: 100, completed: 2011 }
  ];

  const atlasState = {
    dataset: 'current',
    sort: 'height',
    unit: 'm',
    selected: 'Burj Khalifa'
  };

  VALID_MODES.add('buildings');
  const baseRender = render;

  render = function renderWithAtlas() {
    const atlasMode = state.mode === 'buildings';
    document.body.classList.toggle('atlas-mode', atlasMode);
    if (!atlasMode) {
      baseRender();
      return;
    }
    renderBuildings();
    syncSourceButtons();
    syncModeTabs();
    syncUrlState();
  };

  function dataset() {
    const rows = atlasState.dataset === 'classic' ? classicBuildings : currentBuildings;
    return rows.slice().sort((a, b) => {
      if (atlasState.sort === 'name') return a.name.localeCompare(b.name);
      if (atlasState.sort === 'city') return a.city.localeCompare(b.city) || b.heightM - a.heightM;
      return b.heightM - a.heightM;
    });
  }

  function displayHeight(d) {
    if (atlasState.unit === 'ft') return `${Math.round(d.heightM * 3.28084).toLocaleString('en')} ft`;
    return `${d.heightM.toLocaleString('en')} m`;
  }

  function renderBuildings() {
    const isClassic = atlasState.dataset === 'classic';
    const rows = dataset();
    const tallest = rows.reduce((a, b) => a.heightM > b.heightM ? a : b);
    const selected = rows.find(d => d.name === atlasState.selected) || tallest;
    atlasState.selected = selected.name;

    els.root.innerHTML = `
      <div class="view atlas-view">
        <section class="atlas-hero">
          <div>
            <div class="eyebrow">Visual atlas · D3 skyscrapers</div>
            <h1 class="view-title">Tall buildings, drawn to one scale.</h1>
            <p class="view-deck">A focused height comparison rather than another dashboard. The main skyline uses the current 2026 completed-building ranking; the archive switch reconstructs the small D3 v3 dataset that circulated online in 2016.</p>
          </div>
          <div class="atlas-kpis" aria-label="Skyscraper summary">
            <div><strong>${displayHeight(tallest)}</strong><span>${tallest.name}</span></div>
            <div><strong>${rows.length}</strong><span>${isClassic ? 'classic entries' : 'buildings shown'}</span></div>
            <div><strong>${isClassic ? '2016' : '2026'}</strong><span>${isClassic ? 'archived D3 set' : 'current ranking'}</span></div>
          </div>
        </section>

        <section class="atlas-toolbar" aria-label="Skyscraper chart controls">
          <div class="atlas-control-group">
            <span>Dataset</span>
            <button class="atlas-pill ${!isClassic ? 'active' : ''}" data-atlas-dataset="current">2026 ranking</button>
            <button class="atlas-pill ${isClassic ? 'active' : ''}" data-atlas-dataset="classic">2016 D3 classic</button>
          </div>
          <div class="atlas-control-group">
            <span>Sort</span>
            <button class="atlas-pill ${atlasState.sort === 'height' ? 'active' : ''}" data-atlas-sort="height">Height</button>
            <button class="atlas-pill ${atlasState.sort === 'city' ? 'active' : ''}" data-atlas-sort="city">City</button>
            <button class="atlas-pill ${atlasState.sort === 'name' ? 'active' : ''}" data-atlas-sort="name">Name</button>
          </div>
          <div class="atlas-control-group unit-group">
            <span>Units</span>
            <button class="atlas-pill ${atlasState.unit === 'm' ? 'active' : ''}" data-atlas-unit="m">m</button>
            <button class="atlas-pill ${atlasState.unit === 'ft' ? 'active' : ''}" data-atlas-unit="ft">ft</button>
          </div>
        </section>

        <section class="atlas-stage">
          <div class="atlas-stage-head">
            <div>
              <h2>${isClassic ? 'The 2016 D3 dataset, rebuilt' : 'The 2026 skyline'}</h2>
              <p>${isClassic ? 'Same ten building records as the old D3 v3 Gist; modern layout, responsive SVG and accessible detail.' : 'Top completed buildings from the Skyscraper Center, rendered on a shared architectural-height scale.'}</p>
            </div>
            <span class="atlas-scale-note">0 → ${atlasState.unit === 'ft' ? '3,000 ft' : '900 m'}</span>
          </div>
          <div class="skyline-scroll"><div id="skyline-chart" class="skyline-chart"></div></div>
          <div id="building-detail" class="building-detail" aria-live="polite"></div>
        </section>

        <section class="atlas-reference-grid">
          <article class="atlas-reference-card">
            <span class="reference-year">CURRENT DATA</span>
            <h3>Skyscraper Center · 2026</h3>
            <p>The current view is sourced from the completed-building ranking. It uses architectural height, the metric used for the ranking.</p>
            <a href="${CURRENT_SOURCE}" target="_blank" rel="noreferrer">Open current ranking ↗</a>
          </article>
          <article class="atlas-reference-card">
            <span class="reference-year">D3 v3 · 2016</span>
            <h3>World's Tallest Buildings</h3>
            <p>The recovered Gist contains ten buildings, heights, floors and completion years. The old implementation was a simple clickable D3 bar chart.</p>
            <a href="${CLASSIC_SOURCE}" target="_blank" rel="noreferrer">Open original Gist ↗</a>
          </article>
          <article class="atlas-reference-card">
            <span class="reference-year">FT · D3</span>
            <h3>Animation as explanation</h3>
            <p>John Burn-Murdoch's D3/FT material is kept here as a design reference: motion should communicate magnitude and pace, not decorate the chart.</p>
            <a href="${FT_SOURCE}" target="_blank" rel="noreferrer">Open D3 @ FT ↗</a>
          </article>
        </section>
      </div>`;

    document.querySelectorAll('[data-atlas-dataset]').forEach(button => button.addEventListener('click', () => {
      atlasState.dataset = button.dataset.atlasDataset;
      atlasState.selected = 'Burj Khalifa';
      renderBuildings();
    }));
    document.querySelectorAll('[data-atlas-sort]').forEach(button => button.addEventListener('click', () => {
      atlasState.sort = button.dataset.atlasSort;
      renderBuildings();
    }));
    document.querySelectorAll('[data-atlas-unit]').forEach(button => button.addEventListener('click', () => {
      atlasState.unit = button.dataset.atlasUnit;
      renderBuildings();
    }));

    drawSkyline(rows, selected.name);
  }

  function drawSkyline(rows, selectedName) {
    const host = document.querySelector('#skyline-chart');
    if (!host) return;

    const W = Math.max(1120, rows.length * 86);
    const H = 610;
    const margin = { top: 34, right: 28, bottom: 128, left: 72 };
    const ground = H - margin.bottom;
    const maxMeters = 900;
    const maxDisplay = atlasState.unit === 'ft' ? maxMeters * 3.28084 : maxMeters;
    const value = d => atlasState.unit === 'ft' ? d.heightM * 3.28084 : d.heightM;

    const svg = d3.select(host).append('svg')
      .attr('viewBox', `0 0 ${W} ${H}`)
      .attr('role', 'img')
      .attr('aria-label', `Skyscraper height comparison for ${rows.length} buildings.`);

    const x = d3.scaleBand().domain(rows.map(d => d.name)).range([margin.left, W - margin.right]).paddingInner(.24).paddingOuter(.08);
    const y = d3.scaleLinear().domain([0, maxDisplay]).range([ground, margin.top]);
    const ticks = atlasState.unit === 'ft' ? [500, 1000, 1500, 2000, 2500, 3000] : [100, 200, 300, 400, 500, 600, 700, 800, 900];

    svg.append('g').attr('class', 'atlas-grid')
      .selectAll('line').data(ticks).join('line')
      .attr('x1', margin.left).attr('x2', W - margin.right)
      .attr('y1', d => y(d)).attr('y2', d => y(d));

    svg.append('g').attr('class', 'atlas-y-labels')
      .selectAll('text').data(ticks).join('text')
      .attr('x', margin.left - 12).attr('y', d => y(d) + 4)
      .attr('text-anchor', 'end')
      .text(d => atlasState.unit === 'ft' ? `${d.toLocaleString('en')}` : d);

    svg.append('text').attr('class', 'atlas-axis-unit')
      .attr('x', 18).attr('y', 22)
      .text(atlasState.unit === 'ft' ? 'feet' : 'metres');

    svg.append('line').attr('class', 'ground-line')
      .attr('x1', margin.left).attr('x2', W - margin.right)
      .attr('y1', ground).attr('y2', ground);

    const groups = svg.selectAll('g.tower').data(rows, d => d.name).join('g')
      .attr('class', d => `tower ${d.name === selectedName ? 'selected' : ''}`)
      .attr('tabindex', 0)
      .attr('role', 'button')
      .attr('aria-label', d => `${d.name}, ${d.city}, ${displayHeight(d)}`)
      .on('mouseenter focus', (_, d) => selectBuilding(svg, rows, d))
      .on('click', (_, d) => selectBuilding(svg, rows, d));

    groups.append('path')
      .attr('class', 'tower-shape')
      .attr('d', d => {
        const band = x.bandwidth();
        const width = Math.min(58, band * .72);
        const cx = x(d.name) + band / 2;
        const top = y(value(d));
        return silhouettePath(d, cx, ground, top, width);
      })
      .attr('opacity', 0)
      .attr('transform', 'translate(0 16)')
      .transition().duration(520).delay((_, i) => i * 28)
      .attr('opacity', 1).attr('transform', 'translate(0 0)');

    groups.append('text').attr('class', 'height-label')
      .attr('x', d => x(d.name) + x.bandwidth() / 2)
      .attr('y', d => y(value(d)) - 10)
      .attr('text-anchor', 'middle')
      .text(d => atlasState.unit === 'ft' ? `${Math.round(value(d)).toLocaleString('en')}` : `${d.heightM}`);

    groups.append('text').attr('class', 'tower-name')
      .attr('x', d => x(d.name) + x.bandwidth() / 2)
      .attr('y', ground + 20)
      .attr('text-anchor', 'end')
      .attr('transform', d => {
        const cx = x(d.name) + x.bandwidth() / 2;
        return `rotate(-48 ${cx} ${ground + 20})`;
      })
      .text(d => d.short);

    groups.append('text').attr('class', 'tower-city')
      .attr('x', d => x(d.name) + x.bandwidth() / 2)
      .attr('y', ground + 104)
      .attr('text-anchor', 'middle')
      .text(d => d.city);

    const selected = rows.find(d => d.name === selectedName) || rows[0];
    updateDetail(selected);
  }

  function selectBuilding(svg, rows, d) {
    atlasState.selected = d.name;
    svg.selectAll('g.tower').classed('selected', row => row.name === d.name);
    updateDetail(d);
  }

  function updateDetail(d) {
    const detail = document.querySelector('#building-detail');
    if (!detail || !d) return;
    const classic = atlasState.dataset === 'classic';
    const rank = d.rank ? `<span><b>#${d.rank}</b> 2026 rank</span>` : '';
    const extra = classic
      ? `<span><b>${d.floors}</b> floors</span><span><b>${d.completed}</b> completed</span>`
      : '';
    detail.innerHTML = `
      <div class="building-detail-primary">
        <span class="detail-kicker">Selected building</span>
        <h3>${d.name}</h3>
        <p>${d.city}${d.country ? ` · ${d.country}` : ''}</p>
      </div>
      <div class="building-detail-metrics">
        <span><b>${displayHeight(d)}</b> architectural height</span>
        ${rank}${extra}
      </div>`;
  }

  function silhouettePath(d, cx, ground, top, width) {
    const h = ground - top;
    const left = cx - width / 2;
    const right = cx + width / 2;
    const n = d.name.toLowerCase();

    if (n.includes('burj khalifa')) {
      return `M${left},${ground} L${left},${ground-h*.48} L${cx-width*.34},${ground-h*.48} L${cx-width*.34},${ground-h*.67} L${cx-width*.22},${ground-h*.67} L${cx-width*.22},${ground-h*.80} L${cx-width*.12},${ground-h*.80} L${cx-width*.12},${ground-h*.91} L${cx-width*.04},${ground-h*.91} L${cx},${top} L${cx+width*.04},${ground-h*.91} L${cx+width*.12},${ground-h*.91} L${cx+width*.12},${ground-h*.80} L${cx+width*.22},${ground-h*.80} L${cx+width*.22},${ground-h*.67} L${cx+width*.34},${ground-h*.67} L${right},${ground-h*.48} L${right},${ground} Z`;
    }
    if (n.includes('merdeka')) {
      return `M${left},${ground} L${cx-width*.36},${top+h*.26} L${cx-width*.12},${top+h*.08} L${cx-width*.04},${top+h*.08} L${cx},${top} L${cx+width*.07},${top+h*.13} L${cx+width*.23},${top+h*.21} L${right},${ground} Z`;
    }
    if (n.includes('shanghai tower')) {
      return `M${left},${ground} Q${cx-width*.38},${top+h*.35} ${cx-width*.12},${top+h*.09} Q${cx+width*.18},${top} ${cx+width*.28},${top+h*.18} Q${right},${top+h*.45} ${right},${ground} Z`;
    }
    if (n.includes('makkah')) {
      const crown = top + h*.17;
      return `M${left},${ground} L${left},${crown+h*.14} L${cx-width*.34},${crown+h*.14} L${cx-width*.34},${crown} L${cx-width*.16},${crown} L${cx-width*.10},${top+h*.07} L${cx-width*.04},${top+h*.07} L${cx},${top} L${cx+width*.04},${top+h*.07} L${cx+width*.10},${top+h*.07} L${cx+width*.16},${crown} L${cx+width*.34},${crown} L${cx+width*.34},${crown+h*.14} L${right},${crown+h*.14} L${right},${ground} Z`;
    }
    if (n.includes('taipei')) {
      const p = i => ground - h * i;
      return `M${left},${ground} L${left},${p(.17)} L${cx-width*.42},${p(.17)} L${cx-width*.42},${p(.32)} L${left},${p(.32)} L${left},${p(.47)} L${cx-width*.40},${p(.47)} L${cx-width*.40},${p(.62)} L${left},${p(.62)} L${left},${p(.77)} L${cx-width*.28},${p(.77)} L${cx-width*.28},${p(.90)} L${cx-width*.08},${p(.90)} L${cx},${top} L${cx+width*.08},${p(.90)} L${cx+width*.28},${p(.90)} L${cx+width*.28},${p(.77)} L${right},${p(.77)} L${right},${p(.62)} L${cx+width*.40},${p(.62)} L${cx+width*.40},${p(.47)} L${right},${p(.47)} L${right},${p(.32)} L${cx+width*.42},${p(.32)} L${cx+width*.42},${p(.17)} L${right},${p(.17)} L${right},${ground} Z`;
    }
    if (n.includes('one world')) {
      return `M${left},${ground} L${cx-width*.28},${top+h*.18} L${cx-width*.05},${top+h*.08} L${cx},${top} L${cx+width*.05},${top+h*.08} L${cx+width*.28},${top+h*.18} L${right},${ground} Z`;
    }
    if (n.includes('lotte')) {
      return `M${left},${ground} L${cx-width*.31},${top+h*.13} L${cx-width*.10},${top+h*.03} L${cx},${top} L${cx+width*.10},${top+h*.03} L${cx+width*.31},${top+h*.13} L${right},${ground} Z`;
    }
    if (n.includes('petronas')) {
      return `M${left},${ground} L${left},${top+h*.22} L${cx-width*.30},${top+h*.22} L${cx-width*.22},${top+h*.10} L${cx-width*.07},${top+h*.10} L${cx},${top} L${cx+width*.07},${top+h*.10} L${cx+width*.22},${top+h*.10} L${cx+width*.30},${top+h*.22} L${right},${top+h*.22} L${right},${ground} Z`;
    }

    return `M${left},${ground} L${left},${top+h*.20} L${cx-width*.34},${top+h*.20} L${cx-width*.28},${top+h*.09} L${cx-width*.10},${top+h*.09} L${cx},${top} L${cx+width*.10},${top+h*.09} L${cx+width*.28},${top+h*.09} L${cx+width*.34},${top+h*.20} L${right},${top+h*.20} L${right},${ground} Z`;
  }
})();
