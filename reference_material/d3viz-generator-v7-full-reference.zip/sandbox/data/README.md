# Sandbox data

All files in this folder are small local fixtures for the D3 Recovery Lab.

- `ratp/`: RATP-shaped GeoJSON based on the archived tutorial schema. **Incomplete sample network**, not a full factual RATP export.
- `geo/`: rough/dummy GeoJSON used to keep projections, maps and animations runnable.
- `charts/`: dummy CSV/TSV/JSON files matching the schemas used by reconstructed tutorials.

Run `../generate_dummy_data.py` to regenerate them.

Do not silently treat these fixtures as authoritative datasets. Replace them with exact recovered files or verified open-data sources when available.
