# Bundled recovered DataVis source archive

V4 bundles the `datavis.fr/` portion of the user-supplied `D3_template-main.zip` so source-backed demos can be compared locally without relying on a GitHub CDN at runtime.

## Provenance rule

- The supplied archive README says its D3 exercises were taken from DataVis.fr.
- The recovered pages, JavaScript, CSS and data are preserved as a **working recovered copy**.
- V4 does **not** claim these files are byte-identical to the former production server unless an independent archive checksum proves that later.
- The license file that shipped with the supplied archive is preserved as `D3_TEMPLATE_LICENSE.txt`.
- Exact per-file SHA-256 hashes and demo mappings are recorded in `SOURCE_INDEX.json`.

## Local comparison

The Recovery Lab exposes **Modern rebuild / Recovered page** and **Modern / Recovered JS** toggles for 11 source-backed demos. The raw recovered source remains untouched under `datavis.fr/`. Lightweight HTML wrappers under `runnable/` add a local `<base>` and remove only remote/missing D3 imports so comparison pages load deterministically from the bundle; the modern side uses current D3 v7 APIs.

## What is still not in this archive

The source archive does not contain the priority Paris Metro/RATP fullscreen package, the earthquake `from1901to2020.json`, the temperature-barcode package, the circle-packing `population.json`, the Rue89 word-cloud dataset, the airport Voronoi source package, the historical Paris-street export or the travelling-salesman source package. Those remain in `../RECOVERY_MANIFEST.md`.
