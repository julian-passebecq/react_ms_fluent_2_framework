import csv, json, math, random
from pathlib import Path
from datetime import date, timedelta

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
random.seed(731)


def dump_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')

# 1) Temperature barcode: synthetic anomaly series with a long-run warming signal.
rows = []
for year in range(1880, 2026):
    t = year - 1880
    trend = -0.32 + 0.0091 * t
    cyc = 0.10 * math.sin(t / 5.7) + 0.055 * math.sin(t / 13.0)
    noise = random.uniform(-0.07, 0.07)
    rows.append((year, round(trend + cyc + noise, 3)))
with (DATA/'charts'/'temperature_barcode.csv').open('w', newline='', encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['year','value']); w.writerows(rows)

# 2) Hierarchy used by circle packing and sunburst.
hierarchy = {
    'name':'France (dummy hierarchy)',
    'children':[
        {'name':'Île-de-France','children':[
            {'name':'Paris','population':2268000},{'name':'Hauts-de-Seine','population':1640000},
            {'name':'Seine-Saint-Denis','population':1650000},{'name':'Val-de-Marne','population':1410000}]},
        {'name':'Auvergne-Rhône-Alpes','children':[
            {'name':'Rhône','population':1880000},{'name':'Isère','population':1280000},
            {'name':'Haute-Savoie','population':860000},{'name':'Loire','population':770000}]},
        {'name':'Nouvelle-Aquitaine','children':[
            {'name':'Gironde','population':1650000},{'name':'Pyrénées-Atlantiques','population':700000},
            {'name':'Charente-Maritime','population':670000},{'name':'Dordogne','population':415000}]},
        {'name':'Occitanie','children':[
            {'name':'Haute-Garonne','population':1450000},{'name':'Hérault','population':1210000},
            {'name':'Gard','population':760000},{'name':'Tarn','population':395000}]}
    ]
}
dump_json(DATA/'charts'/'hierarchy.json', hierarchy)

# 3) Line chart dummy market data.
start=date(2025,1,1)
value=112.0
line_rows=[]
for i in range(210):
    d=start+timedelta(days=i)
    drift=0.05 + 0.35*math.sin(i/22)
    value=max(60,value+drift+random.gauss(0,1.7))
    volume=int(1_300_000 + random.random()*3_800_000)
    line_rows.append((d.strftime('%d/%m/%Y'),round(value,2),volume))
with (DATA/'charts'/'linechart.tsv').open('w', newline='', encoding='utf-8') as f:
    w=csv.writer(f,delimiter='\t');w.writerow(['date','close','volume']);w.writerows(line_rows)

# 4) Word cloud corpus counts (dummy editorial vocabulary).
words = [
('AI',930),('China',830),('America',790),('economy',620),('Trump',590),('trade',535),('technology',510),
('Europe',480),('markets',455),('Ukraine',430),('climate',390),('migration',372),('energy',360),('Russia',350),
('business',336),('government',325),('war',315),('chips',301),('jobs',292),('inflation',282),('finance',272),
('robots',266),('tariffs',252),('data',247),('Britain',238),('India',231),('Iran',220),('oil',214),('security',205),
('science',198),('culture',190),('labour',184),('bonds',178),('health',171),('cities',165),('companies',159),
('elections',153),('space',148),('bank',143),('law',139),('Africa',135),('Asia',131),('Canada',128),('France',124),
('Japan',120),('Israel',116),('supply chains',111),('democracy',106),('media',101),('universities',96),('transport',92),
('housing',89),('tax',85),('productivity',81),('electricity',77),('shipping',73),('sanctions',69),('investment',65),('startups',60)
]
with (DATA/'charts'/'words.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['LABEL','COUNT']);w.writerows(words)

# 5) Tiny world GeoJSON. Geometry is intentionally rough and only for sandbox rendering.
# [name, iso, minlon,minlat,maxlon,maxlat]
boxes = [
('Canada','CAN',-141,49,-52,70),('United States','USA',-125,25,-66,49),('Mexico','MEX',-117,14,-86,32),
('Brazil','BRA',-74,-34,-34,5),('Argentina','ARG',-73,-55,-53,-22),('United Kingdom','GBR',-8,50,2,59),
('France','FRA',-5,42,8,51),('Germany','DEU',5,47,15,55),('Nigeria','NGA',3,4,15,14),('South Africa','ZAF',16,-35,33,-22),
('Egypt','EGY',25,22,36,32),('Saudi Arabia','SAU',34,16,56,32),('Iran','IRN',44,25,63,40),('Russia','RUS',30,48,170,72),
('India','IND',68,8,89,35),('China','CHN',74,18,135,54),('Japan','JPN',129,31,146,46),('Australia','AUS',113,-44,154,-10),
('Indonesia','IDN',95,-11,141,6)
]
features=[]
for name,iso,x1,y1,x2,y2 in boxes:
    features.append({'type':'Feature','id':iso,'properties':{'name':name,'iso3':iso},'geometry':{'type':'Polygon','coordinates':[[[x1,y1],[x2,y1],[x2,y2],[x1,y2],[x1,y1]]]}})
world={'type':'FeatureCollection','features':features}
dump_json(DATA/'geo'/'world-mini.geojson', world)

nobel_counts={'USA':350,'GBR':125,'DEU':105,'FRA':72,'RUS':40,'CAN':29,'JPN':28,'CHN':12,'IND':11,'AUS':14,'MEX':3,'BRA':2,'ARG':5,'ZAF':11,'NGA':1,'EGY':4,'IRN':2,'SAU':0,'IDN':0}
with (DATA/'charts'/'nobels.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['country','NobelCount']);
    for iso,v in nobel_counts.items(): w.writerow([iso,v])
world_temp={'CAN':-4.5,'USA':9.2,'MEX':21.0,'BRA':24.5,'ARG':14.6,'GBR':10.2,'FRA':12.4,'DEU':9.9,'NGA':26.8,'ZAF':17.5,'EGY':23.1,'SAU':25.8,'IRN':18.0,'RUS':-5.1,'IND':24.2,'CHN':8.1,'JPN':13.4,'AUS':21.6,'IDN':26.0}
with (DATA/'charts'/'world-temperatures.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['country','temperature']);
    for iso,v in world_temp.items(): w.writerow([iso,v])

# 6) France-ish dummy department shapes (not administrative boundaries).
france_cells=[]
cell_defs=[
('Nord','Hauts-de-France',1.2,49.0,3.5,50.9),('Ouest','Normandie',-1.9,48.2,1.2,49.5),('Paris','Île-de-France',1.6,48.1,3.5,49.2),
('Est','Grand Est',3.5,47.6,7.7,49.7),('Bretagne','Bretagne',-4.7,47.2,-1.5,48.7),('Centre','Centre-Val de Loire',0.2,46.5,3.1,48.2),
('Bourgogne','Bourgogne-Franche-Comté',3.0,46.0,7.0,48.0),('Aquitaine','Nouvelle-Aquitaine',-1.8,43.0,1.7,46.7),
('Auvergne','Auvergne-Rhône-Alpes',2.0,44.2,6.9,46.5),('Occitanie','Occitanie',0.0,42.5,4.4,44.8),('PACA','Provence-Alpes-Côte d’Azur',4.4,43.0,7.6,45.0)
]
for i,(name,region,x1,y1,x2,y2) in enumerate(cell_defs,1):
    france_cells.append({'type':'Feature','id':f'D{i:02d}','properties':{'name':name,'region':region},'geometry':{'type':'Polygon','coordinates':[[[x1,y1],[x2,y1],[x2,y2],[x1,y2],[x1,y1]]]}})
dump_json(DATA/'geo'/'departments-dummy.geojson', {'type':'FeatureCollection','features':france_cells})

# 7) RATP-style sample GeoJSON. Uses the original schema from the archived tutorial.
line_colors={'1':'#FFCD00','4':'#BB4D98','5':'#DE8B53','6':'#6ECA97','14':'#62259D'}
station_specs=[
('La Défense',2.238,48.892,34000000,['1']),('Charles de Gaulle–Étoile',2.295,48.874,42000000,['1','6']),
('Franklin D. Roosevelt',2.309,48.869,13000000,['1']),('Concorde',2.321,48.865,15000000,['1']),('Tuileries',2.329,48.864,6200000,['1']),
('Louvre–Rivoli',2.341,48.861,7800000,['1']),('Châtelet',2.347,48.858,39000000,['1','4','14']),('Bastille',2.369,48.853,15000000,['1','5']),('Nation',2.395,48.848,24000000,['1','6']),
('Porte de Clignancourt',2.344,48.897,11500000,['4']),('Gare du Nord',2.35470307836603,48.8799654432891,49977513,['4','5']),('Gare de l’Est',2.357,48.876,21500000,['4','5']),
('Strasbourg–Saint-Denis',2.354,48.869,12200000,['4']),('République',2.364,48.868,17500000,['5']),('Saint-Michel',2.343,48.853,10200000,['4']),('Montparnasse–Bienvenüe',2.322,48.842,31500000,['4','6']),('Denfert-Rochereau',2.332,48.833,20400000,['4','6']),('Bagneux–Lucie Aubrac',2.317,48.803,7200000,['4']),
('Trocadéro',2.287,48.863,13800000,['6']),('Bir-Hakeim',2.289,48.854,7200000,['6']),('Gare d’Austerlitz',2.366,48.842,14500000,['5']),('Place d’Italie',2.355,48.831,16800000,['5','6']),
('Saint-Denis Pleyel',2.346,48.918,8500000,['14']),('Porte de Clichy',2.314,48.894,9100000,['14']),('Saint-Lazare',2.325,48.875,36000000,['14']),('Madeleine',2.326,48.870,12200000,['14']),('Pyramides',2.333,48.866,9900000,['14']),('Gare de Lyon',2.374,48.844,37500000,['14']),('Bercy',2.380,48.840,10500000,['14']),('Olympiades',2.369,48.827,9400000,['14']),('Aéroport d’Orly',2.359,48.729,11000000,['14'])
]
station_features=[]
for i,(name,lon,lat,traffic,lines) in enumerate(station_specs,1):
    colors=[line_colors[x] for x in lines]
    station_features.append({'type':'Feature','properties':{'ID':str(1800+i),'STATION':name.upper(),'CITY':'Paris','QUARTER':'','TRAFIC':str(traffic),'LINES':'-'.join(lines),'COLORS':'-'.join(colors)},'geometry':{'type':'Point','coordinates':[lon,lat]}})
# Ensure large circles draw under small circles like original.
station_features.sort(key=lambda f:int(f['properties']['TRAFIC']), reverse=True)
dump_json(DATA/'ratp'/'stations.json',{'type':'FeatureCollection','features':station_features})

coords_by_name={s[0]:[s[1],s[2]] for s in station_specs}
paths={
'1':['La Défense','Charles de Gaulle–Étoile','Franklin D. Roosevelt','Concorde','Tuileries','Louvre–Rivoli','Châtelet','Bastille','Nation'],
'4':['Porte de Clignancourt','Gare du Nord','Gare de l’Est','Strasbourg–Saint-Denis','Châtelet','Saint-Michel','Montparnasse–Bienvenüe','Denfert-Rochereau','Bagneux–Lucie Aubrac'],
'5':['Gare du Nord','Gare de l’Est','République','Bastille','Gare d’Austerlitz','Place d’Italie'],
'6':['Charles de Gaulle–Étoile','Trocadéro','Bir-Hakeim','Montparnasse–Bienvenüe','Denfert-Rochereau','Place d’Italie','Nation'],
'14':['Saint-Denis Pleyel','Porte de Clichy','Saint-Lazare','Madeleine','Pyramides','Châtelet','Gare de Lyon','Bercy','Olympiades','Aéroport d’Orly']}
line_features=[]
for line,names in paths.items():
    line_features.append({'type':'Feature','properties':{'LINE':line,'COLOR':line_colors[line]},'geometry':{'type':'LineString','coordinates':[coords_by_name[n] for n in names]}})
dump_json(DATA/'ratp'/'lines.json',{'type':'FeatureCollection','features':line_features})

# 8) Paris street linework, dummy but realistic lat/lon scale.
street_types=['rue','avenue','boulevard','quai','passage']
streets=[]
centers=[(2.32,48.858),(2.34,48.864),(2.36,48.851),(2.30,48.87),(2.38,48.84)]
for i in range(90):
    cx,cy=centers[i%len(centers)]
    angle=(i*0.61)%math.pi
    length=0.007+0.010*random.random()
    dx=math.cos(angle)*length; dy=math.sin(angle)*length*0.65
    typ=street_types[i%len(street_types)]
    name=f"{typ.title()} Démo {i+1}"
    streets.append({'type':'Feature','properties':{'name':name,'type':typ},'geometry':{'type':'LineString','coordinates':[[cx-dx,cy-dy],[cx+dx,cy+dy]]}})
dump_json(DATA/'geo'/'paris-streets-dummy.geojson',{'type':'FeatureCollection','features':streets})

# 9) Airports.
airports=[
('Paris Charles de Gaulle','LFPG',2.5479,49.0097,4215),('Paris Orly','LFPO',2.3652,48.7262,3650),('Nice Côte d’Azur','LFMN',7.2159,43.6584,2960),
('Lyon Saint-Exupéry','LFLL',5.0811,45.7256,4000),('Marseille Provence','LFML',5.2214,43.4393,3500),('Toulouse Blagnac','LFBO',1.3638,43.6293,3500),
('Bordeaux Mérignac','LFBD',-0.7156,44.8283,3100),('Nantes Atlantique','LFRS',-1.6107,47.1532,2900),('Strasbourg','LFST',7.6282,48.5383,2400),
('Lille','LFQQ',3.0894,50.5633,2825),('Montpellier','LFMT',3.9630,43.5762,2600),('Brest','LFRB',-4.4185,48.4479,3100),('Ajaccio','LFKJ',8.8029,41.9236,2407),('Bastia','LFKB',9.4837,42.5527,2520),('Corte (dummy)','LFKT',9.20,42.30,940)
]
with (DATA/'charts'/'french-airport.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['airport','oaci_code','longitude','latitude','length','width','high'])
    for name,code,lon,lat,length in airports:w.writerow([name,code,lon,lat,length,45,random.randint(3,500)])

# 10) Earthquakes dummy GeoJSON spanning 1901-2020.
quakes=[]
for i in range(360):
    y=1901 + (i*119)//359
    m=1+(i*7)%12
    mag=round(6.0 + random.random()*2.8,1)
    lon=random.uniform(-175,175); lat=random.uniform(-55,70)
    quakes.append({'type':'Feature','properties':{'year':y,'month':m,'mag':mag,'place':f'Dummy event {i+1}'},'geometry':{'type':'Point','coordinates':[round(lon,3),round(lat,3)]}})
dump_json(DATA/'geo'/'earthquakes-dummy.geojson',{'type':'FeatureCollection','features':quakes})

# 11) TSP city points in France-like coordinates.
cities=[]
for i in range(34):
    cities.append({'name':f'Commune {i+1}','lon':round(random.uniform(-1.5,6.5),3),'lat':round(random.uniform(43.0,49.8),3)})
dump_json(DATA/'charts'/'tsp-cities.json',cities)

print('Generated sandbox dummy data')
