# DataVis.fr D3 recovery manifest

This folder is a **reconstruction lab**, not a claim that the archived site has been fully recovered byte-for-byte.

The working rule is:

1. Preserve the documented visualization behaviour and data schema.
2. Run on current stable libraries where practical.
3. Prefer bundled recovered source where available; ship clearly labelled local fallback data only when an old source file is still missing.
4. Keep a precise hunt list so an exact original asset can replace the dummy file later without redesigning the demo.


## V4 recovery update — supplied source archive bundled locally

V4 now ships the `datavis.fr/` working copy from the user-supplied `D3_template-main.zip` under `sandbox/recovered/datavis.fr/`. This changes the standard tutorial demos from network-dependent mirror attempts to **local source-backed comparisons**.

- **80 recovered DataVis files** are bundled locally: cleaned HTML, JavaScript, CSS, data files, local D3 v4/v5 runtimes and large `*_original.html` snapshots.
- **11 sandbox demos** now expose **Modern rebuild ↔ Recovered page** and **Modern ↔ Recovered JS** switches.
- `sandbox/recovered/SOURCE_INDEX.json` records every bundled file's relative path, size and SHA-256 plus the demo-to-source mapping.
- `sandbox/recovered/README.md` documents provenance boundaries. The archive's own GPLv3 license file is preserved as `D3_TEMPLATE_LICENSE.txt`; V4 does not infer that every upstream DataVis asset has identical licensing provenance.
- Source-backed demos no longer describe themselves as dummy-only. Synthetic fixtures remain only where exact old assets are still missing.

### Locally source-backed in V4

| Demo | Bundled page/source | Bundled data |
|---|---|---|
| Bar chart | `barchart.html/js/css` | `d3js/barchart/data.tsv` |
| Tooltip | `tooltip.html/js/css` + EETooltip helper | generated in source JS |
| Line chart | `linearchart.html/js/css` | `d3js/linearchart/data.tsv` |
| Advanced line | `linearchart-improve.html/js/css` | `d3js/linearchart-improve/data.tsv` |
| Two-line chart | `twolinearchart.html/js/css` | `d3js/twolinearchart/cac40VSchomage.txt` |
| Stacked bars | `stacked-barchart.html/js/css` | `d3js/stacked-barchart/biberons.txt` |
| France map | `map-firststep.html/js/css` | `departments.json` |
| France population | `map-population.html/js/css` | `departments.json` + `population.csv` |
| Nobel map | `map-nobelprice.html/js/css` | world GeoJSON + `nobels.csv` |
| World temperature globe | `map-world-temperature.html/js/css` | world GeoJSON + `world-temperature.csv` |
| Advanced choropleth | `map-improve.html/js/css` | world GeoJSON + `data.csv` |

The recovered local pages intentionally retain their historical runtime family for comparison. The modern side of the lab remains D3 7.9.0.


## V3 recovery update — new mirrors found

This pass found substantially more than the first recovery pass. In particular, two GitHub mirrors contain files that match the archived DataVis.fr schemas and code comments. The sandbox now tries the recovered RATP, Nobel-map, world-temperature, France-map and line-chart data first, with local fallback files when the network is unavailable.

| Recovery | Status | Mirror / evidence |
|---|---|---|
| RATP `stations.json` | **FOUND** | `dominique-vassard/pres_neo4j/metro/stations.json` — matches Gare du Nord ID, traffic, colours and coordinates |
| RATP `lines.json` | **FOUND** | `dominique-vassard/pres_neo4j/metro/lines.json` — matches the archived `3bis`/`#9A9940` example |
| `map-nobelprice.js` + data | **FOUND** | `sylsta/D3_template/datavis.fr/` and `datavis.fr/d3js/map-nobelprice/` |
| `map-world-temperature.js` + data | **FOUND** | `sylsta/D3_template/datavis.fr/` and `datavis.fr/d3js/map-world-temperature/` |
| `map-firststep.js` + `departments.json` | **FOUND** | `sylsta/D3_template/datavis.fr/` |
| `linearchart.js` + `data.tsv` | **FOUND** | `sylsta/D3_template/datavis.fr/` |
| `stacked-barchart.js` + `biberons.txt` | **FOUND** | `sylsta/D3_template/datavis.fr/` |
| advanced map / two-line / bar-chart data | **FOUND** | several matching assets under `sylsta/D3_template/datavis.fr/d3js/` |
| RATP `fullscreenBilouette.html` | **NOT FOUND** | exact-name web + GitHub searches returned no useful mirror |
| Earthquake `from1901to2020.json` | **PARTIAL** | derivative GitHub implementations reference the exact filename, but the large original data file was not recovered |

## Runtime used by the sandbox

- D3: **7.9.0**
- Leaflet: **1.9.4** (stable; not the 2.0 alpha)
- d3-cloud: **1.2.9**
- Map tiles for current runnable demos: CARTO light/no-label tiles with OpenStreetMap/CARTO attribution.
- The retired Stamen Toner Lite URL is documented below but is not a hard runtime dependency.

## P0 — Paris metro / RATP

This is the highest-priority recovery because the archived tutorial contains enough structural detail to make a faithful modern rebuild.

### What the archive documents

The tutorial used three RATP open-data inputs:

- annual entering traffic by station;
- line indices / colours;
- station geographic positions.

The author then merged them into two intermediate files and converted those to two GeoJSON `FeatureCollection`s:

- `stations.json`: Point features with `ID`, `STATION`, `CITY`, `QUARTER`, `TRAFIC`, `LINES`, `COLORS`;
- `lines.json`: ordered LineString geometry with `LINE` and `COLOR`.

The documented Gare du Nord example has:

```json
{
  "ID": "1842",
  "STATION": "GARE DU NORD",
  "TRAFIC": "49977513",
  "LINES": "4-5",
  "COLORS": "#BB4D98-#DE8B53",
  "coordinates": [2.35470307836603, 48.8799654432891]
}
```

The local sample preserves those traffic/line/colour/coordinate values even though its complete network is synthetic/incomplete.

### Exact files / pages to hunt

| Priority | Asset | Archived/original path | Current sandbox status |
|---|---|---|---|
| P0 | Fullscreen page | `https://www.datavis.fr/tutorials/playing/metro/fullscreen.html` | behavior reconstructed |
| P0 | Alternate fullscreen | `https://www.datavis.fr/tutorials/playing/metro/fullscreenBilouette.html` | missing |
| P0 | Stations GeoJSON | `https://www.datavis.fr/tutorials/playing/playing/metro/stations.json` | **matching GitHub mirror found; local fallback retained** |
| P0 | Lines GeoJSON | `https://www.datavis.fr/tutorials/playing/playing/metro/lines.json` | **matching GitHub mirror found; local fallback retained** |
| P1 | Screenshot | `https://www.datavis.fr/tutorials/playing/metro/screenshot.jpg` | archival reference only |
| P1 | 2013 traffic source | RATP open-data “Trafic annuel entrant par station” | public replacements exist |
| P1 | line colours/indices | old `data.ratp.fr` line-colour dataset | current replacement to map |
| P1 | station coordinates | old `data.ratp.fr` station-position dataset | current IDFM replacement exists |

### Map tile dependency to replace / optionally recover

The archived code used Stamen Toner Lite:

```text
http://{s}.tile.stamen.com/toner-lite/{z}/{x}/{y}.png
```

and also referenced:

```js
new L.StamenTileLayer("toner-lite")
```

That old endpoint should be treated as historical. The live rebuild uses a neutral CARTO no-label basemap. If visual archaeology matters, recover a screenshot or an archived tile-equivalent rather than making the retired Stamen URL a production dependency.

### Modern API migration

```text
D3 3.x                       -> D3 7.9.0
Leaflet 0.7.3                -> Leaflet 1.9.4
queue().defer().await()      -> Promise.all([...])
d3.geo.transform(...)       -> d3.geoTransform(...)
d3.geo.path()               -> d3.geoPath(...)
legacy Stamen tile endpoint  -> supported CARTO/OSM tile layer
```

## Other high-value files to hunt

| Demo | Exact / likely original assets | Local fallback now |
|---|---|---|
| Temperature barcode | `bar-code-temperature.js`, `bar-code-temperature.css`, `world-temperature-1880-2022.csv` | `data/charts/temperature_barcode.csv` |
| Circle packing (“Bubble Chart”) | `bubblechart.js`, `bubblechart.css`, `population.json` | `data/charts/hierarchy.json` |
| Non-linear Nobel choropleth | `map-nobelprice.js`, `map-nobelprice.css`, `world-countries-no-antartica.json`, `nobels.csv` | **bundled recovered source + local compare page** |
| Orthographic world temperature | `map-world-temperature.js`, `.css`, `world-countries.json`, `world-temperature.csv` | **bundled recovered source + local compare page** |
| Line chart | `linearchart.js`, `linearchart.css`, `data.tsv` | **bundled recovered source + local compare page** |
| Word cloud | `word-cloud.js`, `word-cloud.css`, `wordsCount2016.csv` | `data/charts/words.csv` |
| France interactive map | `map-firststep.js`, `map-firststep.css`, `departments.json` | **bundled recovered source + local compare page** |
| Paris streets | `fullscreen.html` + full Open Data Paris `voie` GeoJSON | `paris-streets-dummy.geojson` |
| French airports | `leaflet-voronoi.js`, `.css`, original airport TSV/CSV | `french-airport.csv` |
| Earthquakes | `fullscreen.html`, `from1901to2020.json` | `earthquakes-dummy.geojson` |
| Prime numbers | `prime.js`, `prime.css` | no data file needed; algorithm rebuilt |
| Travelling salesman | `salesman-problem.js`, `.css`, commune/department source data | `tsp-cities.json` |

## Current real-data replacement candidates

For the RATP rebuild, exact historical files are ideal, but the visualization can also be rebuilt against current/open equivalents:

- RATP 2013 entering-traffic dataset on data.gouv.fr. Some listings expose XLS/PDF and an older mirrored listing exposes CSV/JSON.
- Île-de-France Mobilités “Gares et stations du réseau ferré d'Île-de-France (donnée généralisée)” for current station geography.
- Île-de-France Mobilités “Gares et stations du réseau ferré d'Île-de-France (par ligne)” for station-by-line relationships.

A future `scripts/build_ratp_real_data.py` should normalize those sources into the archived `stations.json` / `lines.json` schema. That lets the visualization stay stable while source providers change.

## 44-tutorial inventory

`recovery_inventory.json` contains the 44 entries recovered from the archived DataVis.fr catalogue. **Twenty-five are live in the V4 sandbox**, including a new source-backed tooltip reconstruction. The rest are indexed so they can be added incrementally.

### Live now

1. Code barre des températures
2. Frequency Trails
3. Graphique en essaims (Swarm Chart)
4. Histogramme Empilé (Stacked Bar Chart)
5. Sunburst Chart
6. Heatmap (carte de chaleur)
7. Word Cloud (nuage de mots)
8. Projection orthographique
9. Animation & Transition
10. Bulles (Bubble Chart) — correctly labelled circle packing in the lab
11. Carte choroplèthe (non linéaire)
12. Ligne (Linear Chart)
13. Carte interactive
14. Les types de voies à Paris
15. Le voyageur de commerce
16. Liste des aéroports français
17. Nombres Premiers
18. Tremblements de terre depuis 1900
19. Trafic des stations du métro de Paris
20. Histogramme (Bar Chart) — recovered source/data mirror
21. Lignes (Linear Chart) — recovered dual-axis source/data mirror
22. Lignes avancées (Linear Chart) — recovered source/data mirror
23. Carte choroplèthe (population) — recovered source/data mirror
24. Carte choroplèthe avancée — recovered source/data mirror
25. Tooltip — recovered local page/source + modern native-pointer rebuild

### Indexed, not rebuilt yet

- Map Hexgrid
- Premiers Pas
- Présentation
- Deck.gl — Heatmap
- Deck.gl — Première Carte
- Leaflet Map — Carte choroplèthe
- Leaflet Map — Control
- Leaflet Map — Heat Map
- Leaflet Map — Groupement de markers
- Leaflet Map — Première Carte
- Google Maps — Groupement de markers
- Google Maps — Gestion des markers
- Google Maps — Première Carte
- Dashboard sur le Coronavirus
- Simulation de crue à Paris
- Fuite des données du site Ashley Madison
- Traitement des données de Transparence Santé
- De l'importance de vérifier ses données
- Carte (Optimisation)

## Fallback-data policy

Synthetic fallback files remain deliberately small and human-readable. They are not presented as factual statistical datasets. Source-backed V4 demos use the bundled recovered assets instead; fallbacks are retained only for tutorials whose exact old package is still missing. Their job is to preserve:

- the input schema;
- the D3 data join;
- the layout/projection logic;
- interactions;
- API migration patterns.

Once an exact archived asset or a better current open-data source is found, replace the file under `sandbox/data/` while retaining its normalized schema.

## Re-generate local dummy files

From `sandbox/`:

```bash
python generate_dummy_data.py
```

Then serve the repository over HTTP (D3 fetch will not reliably load local JSON/CSV via `file://`):

```bash
python -m http.server 8080
```

Open `http://localhost:8080/sandbox/` if serving from the project root.
